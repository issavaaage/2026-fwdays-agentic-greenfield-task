import * as React from "react";

export type PokemonType =
  | "normal" | "fire" | "water" | "electric" | "grass" | "ice"
  | "fighting" | "poison" | "ground" | "flying" | "psychic" | "bug"
  | "rock" | "ghost" | "dragon" | "dark" | "steel" | "fairy";

/** All 18 canonical type ids, in National-Dex order. */
export const POKEMON_TYPES: PokemonType[];

/**
 * The colored elemental-type pill (FR-LIST-02, FR-DETAIL-02). In `selectable`
 * mode it becomes a toggle button for the multi-select type filter
 * (FR-FILTER-01): selected = filled type color, unselected = neutral outline.
 *
 * @startingPoint section="Data display" subtitle="The 18 colored type pills" viewport="700x140"
 */
export interface TypeBadgeProps
  extends Omit<React.HTMLAttributes<HTMLElement>, "type"> {
  /** Elemental type id. */
  type: PokemonType;
  /** @default "md" */
  size?: "md" | "lg";
  /** Show the leading color dot. @default true */
  dot?: boolean;
  /** Render as a toggle button (filter use). @default false */
  selectable?: boolean;
  /** Selected state when `selectable`. */
  selected?: boolean;
  onClick?: (e: React.MouseEvent) => void;
}

export function TypeBadge(props: TypeBadgeProps): React.ReactElement;

The base surface — a bordered white panel with the brand radius and a whisper shadow. Editorial UI leans on the border; the shadow only deepens on hover for interactive cards.

```jsx
<Card padded>Static panel content</Card>
<Card href="/pokemon/25" interactive>…</Card>
```

`interactive` (or `href`) adds the hover lift + focus ring. Build composite cards like `PokemonCard` on top of this.

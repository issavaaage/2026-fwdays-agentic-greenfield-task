import React from "react";

const CSS = `
.ds-card {
  display: block;
  background: var(--surface-card);
  border: 1px solid var(--border-subtle);
  border-radius: var(--radius-card);
  box-shadow: var(--shadow-card);
  overflow: hidden;
}
.ds-card--pad { padding: var(--space-5); }
.ds-card--interactive {
  cursor: pointer;
  text-decoration: none;
  color: inherit;
  transition: border-color .16s ease, box-shadow .16s ease, transform .16s ease;
}
.ds-card--interactive:hover {
  border-color: var(--border-strong);
  box-shadow: var(--shadow-card-hover);
  transform: translateY(-2px);
}
.ds-card--interactive:active { transform: translateY(0); }
.ds-card--interactive:focus-visible { outline: 2px solid var(--focus-ring); outline-offset: 2px; }
`;

if (typeof document !== "undefined" && !document.getElementById("ds-style-card")) {
  const el = document.createElement("style");
  el.id = "ds-style-card";
  el.textContent = CSS;
  document.head.appendChild(el);
}

export function Card({
  interactive = false,
  padded = false,
  as,
  href,
  className = "",
  children,
  ...rest
}) {
  const Tag = as || (href ? "a" : "div");
  const classes = [
    "ds-card",
    padded ? "ds-card--pad" : "",
    interactive || href ? "ds-card--interactive" : "",
    className,
  ].filter(Boolean).join(" ");
  return (
    <Tag className={classes} href={href} {...rest}>
      {children}
    </Tag>
  );
}

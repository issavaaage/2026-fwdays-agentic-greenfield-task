import React from "react";

const CSS = `
.ds-badge {
  display: inline-flex;
  align-items: center;
  gap: var(--space-1-5);
  height: 22px;
  padding: 0 var(--space-2-5, 10px);
  font-family: var(--font-mono);
  font-size: var(--text-2xs);
  font-weight: var(--weight-medium);
  letter-spacing: var(--tracking-wide);
  text-transform: uppercase;
  border-radius: var(--radius-badge);
  border: 1px solid transparent;
  white-space: nowrap;
}
.ds-badge--neutral { background: var(--surface-sunken); color: var(--text-secondary); border-color: var(--border-subtle); }
.ds-badge--outline { background: transparent; color: var(--text-secondary); border-color: var(--border-default); }
.ds-badge--solid { background: var(--action-primary); color: var(--action-on-primary); }
.ds-badge--legendary { background: var(--legendary-bg); color: var(--legendary); }
.ds-badge--danger { background: var(--danger-bg); color: var(--danger); }
.ds-badge--success { background: var(--success-bg); color: var(--success); }
.ds-badge--lg { height: 26px; font-size: var(--text-xs); padding: 0 var(--space-3); }
.ds-badge__dot { width: 6px; height: 6px; border-radius: 50%; background: currentColor; flex: none; }
`;

if (typeof document !== "undefined" && !document.getElementById("ds-style-badge")) {
  const el = document.createElement("style");
  el.id = "ds-style-badge";
  el.textContent = CSS;
  document.head.appendChild(el);
}

export function Badge({
  variant = "neutral",
  size = "md",
  dot = false,
  className = "",
  children,
  ...rest
}) {
  const classes = [
    "ds-badge",
    `ds-badge--${variant}`,
    size === "lg" ? "ds-badge--lg" : "",
    className,
  ].filter(Boolean).join(" ");
  return (
    <span className={classes} {...rest}>
      {dot ? <span className="ds-badge__dot" /> : null}
      {children}
    </span>
  );
}

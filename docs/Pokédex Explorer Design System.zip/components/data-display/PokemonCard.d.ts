import * as React from "react";
import type { PokemonType } from "./TypeBadge";

/** Build the official-artwork CDN URL for a dex id. */
export function artworkUrl(id: number | string): string;

/**
 * The list grid's core tile (FR-LIST-01..03): official artwork on a soft
 * radial pedestal, mono dex number, capitalized name, and type badges.
 * Clicking navigates to the detail page. Artwork falls back to the PokéAPI
 * CDN when `image` is omitted but `id` is given.
 *
 * @startingPoint section="Data display" subtitle="The Pokémon list-grid tile" viewport="260x320"
 */
export interface PokemonCardProps
  extends Omit<React.HTMLAttributes<HTMLElement>, "id"> {
  /** Dex number; also drives the fallback artwork URL. */
  id?: number | string;
  /** Display name. */
  name?: string;
  /** Elemental types (1–2). */
  types?: PokemonType[];
  /** Explicit artwork URL; defaults to artworkUrl(id). */
  image?: string;
  /** Detail-page link. */
  href?: string;
  onClick?: (e: React.MouseEvent) => void;
}

export function PokemonCard(props: PokemonCardProps): React.ReactElement;

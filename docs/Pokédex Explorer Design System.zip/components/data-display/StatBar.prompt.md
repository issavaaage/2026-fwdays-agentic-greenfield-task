A single base-stat row for the detail page: mono label, mono value, and a monochrome fill bar that darkens by value tier (low/mid/high).

```jsx
<StatBar label="HP" value={78} />
<StatBar label="Attack" value={84} />
<StatBar label="Speed" value={100} />
```

Stack six of these for the full stat block (HP, Attack, Defense, Sp. Atk, Sp. Def, Speed). `max` defaults to 255.

The list grid's core tile: official artwork on a soft radial pedestal, a mono dex number, the name, and type badges. Clicking opens the detail page.

```jsx
<PokemonCard id={6} name="Charizard" types={["fire","flying"]} href="/pokemon/6" />
```

Pass `image` to override the artwork; otherwise it derives the URL from `id` via the exported `artworkUrl(id)`. Built on `Card` (inherits the hover lift) and `TypeBadge`.

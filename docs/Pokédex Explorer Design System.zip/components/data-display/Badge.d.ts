import * as React from "react";

export type BadgeVariant =
  | "neutral"
  | "outline"
  | "solid"
  | "legendary"
  | "danger"
  | "success";

/**
 * A small mono-uppercase status pill. Use for non-type metadata: dex era,
 * a Legendary / Mythical label (FR-DETAIL-08), counts, or system status.
 * For Pokémon elemental types use `TypeBadge`.
 */
export interface BadgeProps extends React.HTMLAttributes<HTMLSpanElement> {
  /** @default "neutral" */
  variant?: BadgeVariant;
  /** @default "md" */
  size?: "md" | "lg";
  /** Show a leading status dot. @default false */
  dot?: boolean;
  children?: React.ReactNode;
}

export function Badge(props: BadgeProps): React.ReactElement;

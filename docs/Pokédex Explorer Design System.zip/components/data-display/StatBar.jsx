import React from "react";

const CSS = `
.ds-stat { display: grid; grid-template-columns: 92px 40px 1fr; align-items: center; gap: var(--space-3); }
.ds-stat__label {
  font-family: var(--font-mono);
  font-size: var(--text-2xs);
  font-weight: var(--weight-medium);
  letter-spacing: var(--tracking-wide);
  text-transform: uppercase;
  color: var(--text-tertiary);
}
.ds-stat__value {
  font-family: var(--font-mono);
  font-size: var(--text-sm);
  font-weight: var(--weight-medium);
  font-variant-numeric: tabular-nums;
  color: var(--text-primary);
  text-align: right;
}
.ds-stat__track {
  position: relative;
  height: 8px;
  background: var(--surface-sunken);
  border-radius: var(--radius-pill);
  overflow: hidden;
}
.ds-stat__fill {
  position: absolute; inset: 0 auto 0 0;
  height: 100%;
  background: var(--ink-900);
  border-radius: var(--radius-pill);
  transition: width .5s cubic-bezier(.4,0,.2,1);
}
.ds-stat--low .ds-stat__fill { background: var(--ink-400); }
.ds-stat--mid .ds-stat__fill { background: var(--ink-600); }
.ds-stat--high .ds-stat__fill { background: var(--ink-900); }
`;

if (typeof document !== "undefined" && !document.getElementById("ds-style-stat")) {
  const el = document.createElement("style");
  el.id = "ds-style-stat";
  el.textContent = CSS;
  document.head.appendChild(el);
}

export function StatBar({
  label,
  value = 0,
  max = 255,
  className = "",
  ...rest
}) {
  const pct = Math.max(0, Math.min(100, (value / max) * 100));
  const tier = value >= 100 ? "high" : value >= 60 ? "mid" : "low";
  const classes = ["ds-stat", `ds-stat--${tier}`, className].filter(Boolean).join(" ");
  return (
    <div className={classes} {...rest}>
      <span className="ds-stat__label">{label}</span>
      <span className="ds-stat__value">{value}</span>
      <span className="ds-stat__track" role="meter" aria-valuenow={value} aria-valuemin={0} aria-valuemax={max} aria-label={label}>
        <span className="ds-stat__fill" style={{ width: `${pct}%` }} />
      </span>
    </div>
  );
}

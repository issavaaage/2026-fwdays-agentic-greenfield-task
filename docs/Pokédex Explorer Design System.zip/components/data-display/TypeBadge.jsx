import React from "react";

export const POKEMON_TYPES = [
  "normal", "fire", "water", "electric", "grass", "ice",
  "fighting", "poison", "ground", "flying", "psychic", "bug",
  "rock", "ghost", "dragon", "dark", "steel", "fairy",
];

const CSS = `
.ds-type {
  display: inline-flex;
  align-items: center;
  gap: var(--space-1-5);
  height: 22px;
  padding: 0 var(--space-2-5, 10px);
  font-family: var(--font-mono);
  font-size: var(--text-2xs);
  font-weight: var(--weight-medium);
  letter-spacing: var(--tracking-wide);
  text-transform: uppercase;
  border-radius: var(--radius-badge);
  border: 1px solid transparent;
  white-space: nowrap;
  background: var(--_bg);
  color: var(--_fg);
  cursor: default;
}
.ds-type--lg { height: 28px; font-size: var(--text-xs); padding: 0 var(--space-3); gap: var(--space-2); }
.ds-type__dot { width: 7px; height: 7px; border-radius: 50%; background: var(--_dot); flex: none; }
.ds-type--selectable { cursor: pointer; transition: filter .12s ease, box-shadow .12s ease; }
.ds-type--selectable:hover { filter: brightness(.97); }
.ds-type--selected { box-shadow: inset 0 0 0 1.5px var(--_dot); }
.ds-type[aria-pressed="false"] { background: var(--surface-card); color: var(--text-secondary); border-color: var(--border-default); }
.ds-type[aria-pressed="false"] .ds-type__dot { background: var(--_dot); }
.ds-type[aria-pressed="false"]:hover { border-color: var(--ink-400); filter: none; }
`;

if (typeof document !== "undefined" && !document.getElementById("ds-style-type")) {
  const el = document.createElement("style");
  el.id = "ds-style-type";
  el.textContent = CSS;
  document.head.appendChild(el);
}

export function TypeBadge({
  type,
  size = "md",
  dot = true,
  selectable = false,
  selected,
  onClick,
  className = "",
  ...rest
}) {
  const t = String(type || "normal").toLowerCase();
  const style = {
    "--_bg": `var(--type-${t}-bg)`,
    "--_fg": `var(--type-${t}-text)`,
    "--_dot": `var(--type-${t})`,
  };
  const classes = [
    "ds-type",
    size === "lg" ? "ds-type--lg" : "",
    selectable ? "ds-type--selectable" : "",
    selectable && selected ? "ds-type--selected" : "",
    className,
  ].filter(Boolean).join(" ");

  const content = (
    <>
      {dot ? <span className="ds-type__dot" /> : null}
      {t}
    </>
  );

  if (selectable) {
    return (
      <button
        type="button"
        className={classes}
        style={style}
        aria-pressed={!!selected}
        onClick={onClick}
        {...rest}
      >
        {content}
      </button>
    );
  }

  return (
    <span className={classes} style={style} {...rest}>
      {content}
    </span>
  );
}

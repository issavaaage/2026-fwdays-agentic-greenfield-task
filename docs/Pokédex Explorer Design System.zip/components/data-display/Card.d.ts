import * as React from "react";

/**
 * The base surface primitive: a bordered, lightly-shadowed white panel with
 * the brand card radius. `interactive` (or passing `href`) adds the hover
 * lift used by clickable cards. Compose richer cards (e.g. PokemonCard) on
 * top of this.
 */
export interface CardProps extends React.HTMLAttributes<HTMLElement> {
  /** Add hover lift + focus ring. @default false */
  interactive?: boolean;
  /** Apply default interior padding. @default false */
  padded?: boolean;
  /** Override the rendered element. Defaults to "a" if href is set, else "div". */
  as?: keyof JSX.IntrinsicElements;
  href?: string;
  children?: React.ReactNode;
}

export function Card(props: CardProps): React.ReactElement;

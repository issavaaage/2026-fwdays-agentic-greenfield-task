import React from "react";
import { Card } from "./Card.jsx";
import { TypeBadge } from "./TypeBadge.jsx";

/** Official artwork CDN URL for a given dex id (PokéAPI sprites repo). */
export function artworkUrl(id) {
  return `https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/${id}.png`;
}

const CSS = `
.ds-pokecard { display: flex; flex-direction: column; }
.ds-pokecard__media {
  position: relative;
  aspect-ratio: 1 / 1;
  background:
    radial-gradient(120% 120% at 50% 18%, var(--surface-card) 0%, var(--surface-sunken) 100%);
  display: flex; align-items: center; justify-content: center;
  border-bottom: 1px solid var(--border-subtle);
}
.ds-pokecard__num {
  position: absolute; top: var(--space-3); left: var(--space-3);
  font-family: var(--font-mono);
  font-size: var(--text-xs);
  font-weight: var(--weight-medium);
  font-variant-numeric: tabular-nums;
  color: var(--text-tertiary);
  letter-spacing: var(--tracking-wide);
}
.ds-pokecard__img {
  width: 72%; height: 72%;
  object-fit: contain;
  image-rendering: auto;
  transition: transform .2s ease;
  filter: drop-shadow(0 6px 10px rgba(14,14,12,.12));
}
.ds-card--interactive:hover .ds-pokecard__img { transform: scale(1.05); }
.ds-pokecard__body { padding: var(--space-3) var(--space-4) var(--space-4); display: flex; flex-direction: column; gap: var(--space-2); }
.ds-pokecard__name {
  font-family: var(--font-sans);
  font-size: var(--text-lg);
  font-weight: var(--weight-bold);
  letter-spacing: var(--tracking-tight);
  color: var(--text-primary);
  line-height: var(--leading-tight);
  text-transform: capitalize;
}
.ds-pokecard__types { display: flex; flex-wrap: wrap; gap: var(--space-1-5); }
`;

if (typeof document !== "undefined" && !document.getElementById("ds-style-pokecard")) {
  const el = document.createElement("style");
  el.id = "ds-style-pokecard";
  el.textContent = CSS;
  document.head.appendChild(el);
}

export function PokemonCard({
  id,
  name,
  types = [],
  image,
  href,
  onClick,
  className = "",
  ...rest
}) {
  const dex = id != null ? `#${String(id).padStart(4, "0")}` : null;
  const src = image || (id != null ? artworkUrl(id) : null);
  return (
    <Card
      interactive
      href={href}
      onClick={onClick}
      className={["ds-pokecard", className].filter(Boolean).join(" ")}
      {...rest}
    >
      <div className="ds-pokecard__media">
        {dex ? <span className="ds-pokecard__num">{dex}</span> : null}
        {src ? <img className="ds-pokecard__img" src={src} alt={name || "Pokémon"} loading="lazy" /> : null}
      </div>
      <div className="ds-pokecard__body">
        <div className="ds-pokecard__name">{name}</div>
        <div className="ds-pokecard__types">
          {types.map((t) => <TypeBadge key={t} type={t} />)}
        </div>
      </div>
    </Card>
  );
}

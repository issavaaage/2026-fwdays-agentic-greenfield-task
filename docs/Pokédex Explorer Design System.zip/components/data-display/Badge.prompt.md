A small mono-uppercase pill for non-type metadata: a Legendary / Mythical label, generation era, counts, or system status.

```jsx
<Badge variant="legendary">Legendary</Badge>
<Badge variant="neutral">Gen 1</Badge>
<Badge variant="success" dot>Live</Badge>
```

Variants: `neutral` · `outline` · `solid` · `legendary` · `danger` · `success`. For elemental types, use `TypeBadge`.

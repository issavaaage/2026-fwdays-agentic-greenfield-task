import * as React from "react";

/**
 * A single base-stat row (FR-DETAIL-04): mono label, mono value, and a
 * monochrome fill bar. The fill darkens in three tiers by value so a stat
 * line scans at a glance without introducing color.
 */
export interface StatBarProps extends React.HTMLAttributes<HTMLDivElement> {
  /** Stat name, e.g. "HP", "Attack", "Sp. Atk". */
  label: string;
  /** Stat value. */
  value: number;
  /** Scale ceiling for the bar. @default 255 */
  max?: number;
}

export function StatBar(props: StatBarProps): React.ReactElement;

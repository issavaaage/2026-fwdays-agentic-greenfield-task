The colored elemental-type pill — the single most-used colored element in the product. Static on cards and the detail page; `selectable` turns it into a toggle for the type filter.

```jsx
<TypeBadge type="fire" />
<TypeBadge type="water" size="lg" />

// Multi-select type filter
{POKEMON_TYPES.map(t => (
  <TypeBadge key={t} type={t} selectable
    selected={active.has(t)} onClick={() => toggle(t)} />
))}
```

Exports `POKEMON_TYPES` (all 18 ids). Each type maps to `--type-<t>` / `--type-<t>-bg` / `--type-<t>-text` tokens.

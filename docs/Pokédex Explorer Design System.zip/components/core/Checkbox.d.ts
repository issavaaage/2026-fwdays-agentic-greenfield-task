import * as React from "react";

/**
 * A checkbox with an ink-fill checked state and optional label. Controlled
 * (`checked`) or uncontrolled (`defaultChecked`).
 */
export interface CheckboxProps
  extends Omit<React.InputHTMLAttributes<HTMLInputElement>, "type"> {
  /** Text beside the box. */
  label?: React.ReactNode;
  checked?: boolean;
  defaultChecked?: boolean;
  disabled?: boolean;
}

export function Checkbox(props: CheckboxProps): React.ReactElement;

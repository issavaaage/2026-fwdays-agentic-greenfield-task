An icon-only square button for toolbars, clear/close affordances, and pagination arrows. Always pass a `label` for accessibility.

```jsx
<IconButton label="Clear search"><XIcon /></IconButton>
<IconButton label="Next page" variant="outline"><ChevronRightIcon /></IconButton>
<IconButton label="Open filters" variant="solid"><SlidersIcon /></IconButton>
```

Variants: `ghost` (default) · `outline` · `solid`. Sizes: `sm` · `md` · `lg`.

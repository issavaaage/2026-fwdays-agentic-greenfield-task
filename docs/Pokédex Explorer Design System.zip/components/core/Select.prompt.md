A styled native dropdown for single-select choices — the generation filter (Gen 1–9) is the canonical use.

```jsx
<Select
  label="Generation"
  placeholder="All generations"
  options={[{value:"1",label:"Gen 1 — Kanto"}, {value:"2",label:"Gen 2 — Johto"}]}
  value={gen}
  onChange={e => setGen(e.target.value)}
/>
```

Pass `options` (strings or `{value,label}`) or `<option>` children. For multi-select (type filter) use a set of toggle chips instead.

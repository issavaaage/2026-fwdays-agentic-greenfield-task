import * as React from "react";

export type InputSize = "sm" | "md" | "lg";

/**
 * A single-line text field with an optional mono uppercase label, hint/error
 * text, and leading/trailing icons. Wraps a native <input>, so any input
 * attribute (type, value, onChange, placeholder…) passes through.
 */
export interface InputProps
  extends Omit<React.InputHTMLAttributes<HTMLInputElement>, "size"> {
  /** Mono uppercase eyebrow label above the field. */
  label?: string;
  /** Helper text below the field. */
  hint?: string;
  /** Error message; turns the field red and overrides hint. */
  error?: string;
  /** @default "md" */
  size?: InputSize;
  /** Leading icon inside the field. */
  iconLeft?: React.ReactNode;
  /** Trailing icon inside the field. */
  iconRight?: React.ReactNode;
}

export function Input(props: InputProps): React.ReactElement;

import * as React from "react";

/**
 * The product's primary search affordance: a text field with a leading
 * magnifier and a clear (×) button that appears once there's a value.
 * Built for the debounced name search (FR-SEARCH-01..03). Controlled.
 *
 * @startingPoint section="Core" subtitle="Debounced name search with clear" viewport="700x120"
 */
export interface SearchInputProps
  extends Omit<React.InputHTMLAttributes<HTMLInputElement>, "size" | "onChange" | "value"> {
  /** Current query value (controlled). */
  value?: string;
  /** Fires on every keystroke; debounce upstream. */
  onChange?: (e: { target: { value: string } }) => void;
  /** Optional explicit clear handler; defaults to onChange(""). */
  onClear?: (e?: React.MouseEvent) => void;
  /** @default "Search Pokémon…" */
  placeholder?: string;
  /** @default "md" */
  size?: "md" | "lg";
}

export function SearchInput(props: SearchInputProps): React.ReactElement;

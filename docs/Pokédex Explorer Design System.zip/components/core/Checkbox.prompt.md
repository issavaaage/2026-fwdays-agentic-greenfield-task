A standard checkbox with an ink-filled checked state. Controlled or uncontrolled.

```jsx
<Checkbox label="Only fully evolved" checked={x} onChange={e => setX(e.target.checked)} />
```

For a binary on/off setting that reads as a state (e.g. the Legendary toggle) prefer `Switch`.

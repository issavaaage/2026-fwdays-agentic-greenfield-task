import * as React from "react";

export interface SelectOption {
  value: string;
  label: string;
}

/**
 * A styled native <select> with a mono label and custom chevron. Used for the
 * single-select generation filter (Gen 1–9). Pass `options` or <option>
 * children. All native select attributes pass through.
 */
export interface SelectProps
  extends Omit<React.SelectHTMLAttributes<HTMLSelectElement>, "size"> {
  label?: string;
  /** Options as strings or {value,label} objects. */
  options?: Array<string | SelectOption>;
  /** Leading empty option label (e.g. "All generations"). */
  placeholder?: string;
  /** @default "md" */
  size?: "sm" | "md";
  children?: React.ReactNode;
}

export function Select(props: SelectProps): React.ReactElement;

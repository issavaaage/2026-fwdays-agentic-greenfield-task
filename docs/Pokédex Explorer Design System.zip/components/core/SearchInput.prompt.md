The product's main search box — a magnifier-prefixed field with an auto-appearing clear button. Controlled; debounce the value before pushing to the URL.

```jsx
const [q, setQ] = React.useState("");
<SearchInput value={q} onChange={e => setQ(e.target.value)} />
```

Use `size="lg"` for a prominent hero placement. For generic text entry use `Input` instead.

import React from "react";

const CSS = `
.ds-select-field { display: flex; flex-direction: column; gap: var(--space-1-5); }
.ds-select-field__label {
  font-family: var(--font-mono);
  font-size: var(--text-2xs);
  font-weight: var(--weight-medium);
  letter-spacing: var(--tracking-wider);
  text-transform: uppercase;
  color: var(--text-tertiary);
}
.ds-select-wrap { position: relative; display: flex; align-items: center; }
.ds-select {
  width: 100%;
  height: var(--control-height-md);
  padding: 0 var(--space-9, 38px) 0 var(--space-3);
  font-family: var(--font-sans);
  font-size: var(--text-sm);
  color: var(--text-primary);
  background: var(--surface-card);
  border: 1px solid var(--border-default);
  border-radius: var(--radius-control);
  cursor: pointer;
  appearance: none;
  transition: border-color .15s ease, box-shadow .15s ease;
}
.ds-select:hover:not(:disabled) { border-color: var(--ink-400); }
.ds-select:focus { outline: none; border-color: var(--ink-900); box-shadow: 0 0 0 1px var(--ink-900); }
.ds-select:disabled { background: var(--surface-sunken); color: var(--text-disabled); cursor: not-allowed; }
.ds-select--sm { height: var(--control-height-sm); font-size: var(--text-xs); }
.ds-select__chevron {
  position: absolute; right: var(--space-3); pointer-events: none;
  display: inline-flex; color: var(--text-tertiary);
}
.ds-select__chevron svg { width: 16px; height: 16px; }
`;

if (typeof document !== "undefined" && !document.getElementById("ds-style-select")) {
  const el = document.createElement("style");
  el.id = "ds-style-select";
  el.textContent = CSS;
  document.head.appendChild(el);
}

const Chevron = () => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
    <path d="m6 9 6 6 6-6" />
  </svg>
);

export function Select({
  label,
  options = [],
  placeholder,
  size = "md",
  id,
  className = "",
  children,
  ...rest
}) {
  const reactId = React.useId();
  const selectId = id || reactId;
  const selectClasses = ["ds-select", size !== "md" ? `ds-select--${size}` : "", className].filter(Boolean).join(" ");

  const control = (
    <div className="ds-select-wrap">
      <select id={selectId} className={selectClasses} {...rest}>
        {placeholder ? <option value="">{placeholder}</option> : null}
        {children
          ? children
          : options.map((o) => {
              const opt = typeof o === "string" ? { value: o, label: o } : o;
              return <option key={opt.value} value={opt.value}>{opt.label}</option>;
            })}
      </select>
      <span className="ds-select__chevron"><Chevron /></span>
    </div>
  );

  if (!label) return control;
  return (
    <div className="ds-select-field">
      <label className="ds-select-field__label" htmlFor={selectId}>{label}</label>
      {control}
    </div>
  );
}

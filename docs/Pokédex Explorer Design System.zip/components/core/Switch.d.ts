import * as React from "react";

/**
 * A toggle switch for binary settings that read as on/off state — the
 * Legendary / Mythical filter (FR-FILTER-03) is the canonical use.
 */
export interface SwitchProps
  extends Omit<React.InputHTMLAttributes<HTMLInputElement>, "type"> {
  label?: React.ReactNode;
  checked?: boolean;
  defaultChecked?: boolean;
  disabled?: boolean;
}

export function Switch(props: SwitchProps): React.ReactElement;

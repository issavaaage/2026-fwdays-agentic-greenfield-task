A single-line text field. Pairs a mono uppercase label with a clean bordered input; supports hint/error text and inline icons. All native input attributes pass through.

```jsx
<Input label="Name" placeholder="e.g. Pikachu" value={q} onChange={e => setQ(e.target.value)} />
<Input label="Email" error="That doesn't look right" />
<Input iconLeft={<SearchIcon />} placeholder="Search…" />
```

Sizes: `sm` · `md` · `lg`. For the product's debounced search box, prefer `SearchInput`, which adds a clear button.

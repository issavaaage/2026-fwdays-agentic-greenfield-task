import React from "react";

const CSS = `
.ds-iconbtn {
  --_s: var(--control-height-md);
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: var(--_s);
  height: var(--_s);
  padding: 0;
  border-radius: var(--radius-control);
  border: 1px solid transparent;
  background: transparent;
  color: var(--text-secondary);
  cursor: pointer;
  transition: background-color .15s ease, border-color .15s ease, color .15s ease;
}
.ds-iconbtn:hover:not(:disabled) { background: var(--surface-hover); color: var(--text-primary); }
.ds-iconbtn:active:not(:disabled) { background: var(--surface-active); }
.ds-iconbtn:disabled { opacity: .4; cursor: not-allowed; }
.ds-iconbtn--sm { --_s: var(--control-height-sm); }
.ds-iconbtn--lg { --_s: var(--control-height-lg); }
.ds-iconbtn--outline { border-color: var(--border-default); background: var(--surface-card); }
.ds-iconbtn--outline:hover:not(:disabled) { border-color: var(--ink-400); }
.ds-iconbtn--solid { background: var(--action-primary); color: var(--action-on-primary); }
.ds-iconbtn--solid:hover:not(:disabled) { background: var(--action-primary-hover); }
.ds-iconbtn svg { width: 1.15em; height: 1.15em; }
`;

if (typeof document !== "undefined" && !document.getElementById("ds-style-iconbtn")) {
  const el = document.createElement("style");
  el.id = "ds-style-iconbtn";
  el.textContent = CSS;
  document.head.appendChild(el);
}

export function IconButton({
  size = "md",
  variant = "ghost",
  label,
  disabled = false,
  className = "",
  children,
  ...rest
}) {
  const classes = [
    "ds-iconbtn",
    size !== "md" ? `ds-iconbtn--${size}` : "",
    variant !== "ghost" ? `ds-iconbtn--${variant}` : "",
    className,
  ].filter(Boolean).join(" ");

  return (
    <button className={classes} aria-label={label} title={label} disabled={disabled} {...rest}>
      {children}
    </button>
  );
}

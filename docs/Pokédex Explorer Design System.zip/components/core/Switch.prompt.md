A toggle switch for on/off settings. The Legendary / Mythical filter is the canonical use.

```jsx
<Switch label="Legendary & Mythical only" checked={leg} onChange={e => setLeg(e.target.checked)} />
```

For a checkbox in a list of options, use `Checkbox` instead.

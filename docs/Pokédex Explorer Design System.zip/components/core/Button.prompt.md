A monochrome button for primary, secondary, and tertiary actions. Use `primary` for the single most important action on a view, `secondary` for supporting actions, and `ghost` for low-emphasis or toolbar actions.

```jsx
<Button onClick={save}>Apply filters</Button>
<Button variant="secondary" iconLeft={<SearchIcon />}>Search</Button>
<Button variant="ghost" size="sm">Clear filters</Button>
<Button as="a" href="/pokemon/25">View detail</Button>
```

Variants: `primary` (ink fill) · `secondary` (outline) · `ghost` (text).
Sizes: `sm` (32px) · `md` (40px, default) · `lg` (48px).
Props: `fullWidth`, `disabled`, `iconLeft`, `iconRight`, `as` ("button" | "a"), `href`.

import React from "react";

const CSS = `
.ds-field { display: flex; flex-direction: column; gap: var(--space-1-5); }
.ds-field__label {
  font-family: var(--font-mono);
  font-size: var(--text-2xs);
  font-weight: var(--weight-medium);
  letter-spacing: var(--tracking-wider);
  text-transform: uppercase;
  color: var(--text-tertiary);
}
.ds-field__hint { font-size: var(--text-xs); color: var(--text-tertiary); }
.ds-field__hint--error { color: var(--danger); }

.ds-input-wrap { position: relative; display: flex; align-items: center; }
.ds-input {
  width: 100%;
  height: var(--control-height-md);
  padding: 0 var(--space-3);
  font-family: var(--font-sans);
  font-size: var(--text-sm);
  color: var(--text-primary);
  background: var(--surface-card);
  border: 1px solid var(--border-default);
  border-radius: var(--radius-control);
  transition: border-color .15s ease, box-shadow .15s ease;
  appearance: none;
}
.ds-input::placeholder { color: var(--text-tertiary); }
.ds-input:hover:not(:disabled) { border-color: var(--ink-400); }
.ds-input:focus { outline: none; border-color: var(--ink-900); box-shadow: 0 0 0 1px var(--ink-900); }
.ds-input:disabled { background: var(--surface-sunken); color: var(--text-disabled); cursor: not-allowed; }
.ds-input--error { border-color: var(--danger); }
.ds-input--error:focus { box-shadow: 0 0 0 1px var(--danger); border-color: var(--danger); }
.ds-input--sm { height: var(--control-height-sm); font-size: var(--text-xs); }
.ds-input--lg { height: var(--control-height-lg); font-size: var(--text-base); }
.ds-input--with-icon-left { padding-left: var(--space-10); }
.ds-input--with-icon-right { padding-right: var(--space-10); }

.ds-input-icon {
  position: absolute;
  display: inline-flex;
  align-items: center;
  color: var(--text-tertiary);
  pointer-events: none;
}
.ds-input-icon--left { left: var(--space-3); }
.ds-input-icon--right { right: var(--space-3); }
.ds-input-icon svg { width: 16px; height: 16px; }
`;

if (typeof document !== "undefined" && !document.getElementById("ds-style-input")) {
  const el = document.createElement("style");
  el.id = "ds-style-input";
  el.textContent = CSS;
  document.head.appendChild(el);
}

export function Input({
  label,
  hint,
  error,
  size = "md",
  iconLeft = null,
  iconRight = null,
  id,
  className = "",
  ...rest
}) {
  const reactId = React.useId();
  const inputId = id || reactId;
  const inputClasses = [
    "ds-input",
    size !== "md" ? `ds-input--${size}` : "",
    error ? "ds-input--error" : "",
    iconLeft ? "ds-input--with-icon-left" : "",
    iconRight ? "ds-input--with-icon-right" : "",
    className,
  ].filter(Boolean).join(" ");

  const field = (
    <div className="ds-input-wrap">
      {iconLeft ? <span className="ds-input-icon ds-input-icon--left">{iconLeft}</span> : null}
      <input id={inputId} className={inputClasses} aria-invalid={error ? true : undefined} {...rest} />
      {iconRight ? <span className="ds-input-icon ds-input-icon--right">{iconRight}</span> : null}
    </div>
  );

  if (!label && !hint && !error) return field;

  return (
    <div className="ds-field">
      {label ? <label className="ds-field__label" htmlFor={inputId}>{label}</label> : null}
      {field}
      {error ? <span className="ds-field__hint ds-field__hint--error">{error}</span>
        : hint ? <span className="ds-field__hint">{hint}</span> : null}
    </div>
  );
}

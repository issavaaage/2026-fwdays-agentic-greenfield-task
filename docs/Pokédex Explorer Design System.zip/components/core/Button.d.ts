import * as React from "react";

export type ButtonVariant = "primary" | "secondary" | "ghost";
export type ButtonSize = "sm" | "md" | "lg";

/**
 * Primary interactive control. Monochrome by design: a solid ink fill for the
 * main action, an outline for secondary, and a quiet ghost for tertiary.
 *
 * @startingPoint section="Core" subtitle="Buttons — primary, secondary, ghost" viewport="700x200"
 */
export interface ButtonProps
  extends Omit<React.ButtonHTMLAttributes<HTMLButtonElement>, "children"> {
  /** Visual emphasis. @default "primary" */
  variant?: ButtonVariant;
  /** Control height. @default "md" */
  size?: ButtonSize;
  /** Stretch to fill the container width. @default false */
  fullWidth?: boolean;
  /** Disable interaction and dim the control. @default false */
  disabled?: boolean;
  /** Optional leading icon (e.g. a Lucide <svg>). */
  iconLeft?: React.ReactNode;
  /** Optional trailing icon. */
  iconRight?: React.ReactNode;
  /** Render as a native button or an anchor. @default "button" */
  as?: "button" | "a";
  /** Href when rendered as an anchor. */
  href?: string;
  children?: React.ReactNode;
}

export function Button(props: ButtonProps): React.ReactElement;

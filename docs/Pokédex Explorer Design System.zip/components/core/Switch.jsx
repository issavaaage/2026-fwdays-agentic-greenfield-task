import React from "react";

const CSS = `
.ds-switch { display: inline-flex; align-items: center; gap: var(--space-2-5, 10px); cursor: pointer; user-select: none; }
.ds-switch--disabled { cursor: not-allowed; opacity: .5; }
.ds-switch__native { position: absolute; opacity: 0; width: 0; height: 0; }
.ds-switch__track {
  position: relative;
  width: 36px; height: 20px; flex: none;
  border-radius: var(--radius-pill);
  background: var(--ink-300);
  transition: background-color .16s ease;
}
.ds-switch__thumb {
  position: absolute; top: 2px; left: 2px;
  width: 16px; height: 16px;
  border-radius: var(--radius-full);
  background: var(--ink-0);
  box-shadow: var(--shadow-sm);
  transition: transform .16s cubic-bezier(.4,.0,.2,1);
}
.ds-switch__native:checked + .ds-switch__track { background: var(--action-primary); }
.ds-switch__native:checked + .ds-switch__track .ds-switch__thumb { transform: translateX(16px); }
.ds-switch:hover .ds-switch__native:not(:checked):not(:disabled) + .ds-switch__track { background: var(--ink-400); }
.ds-switch__native:focus-visible + .ds-switch__track { outline: 2px solid var(--focus-ring); outline-offset: 2px; }
.ds-switch__label { font-size: var(--text-sm); color: var(--text-primary); }
`;

if (typeof document !== "undefined" && !document.getElementById("ds-style-switch")) {
  const el = document.createElement("style");
  el.id = "ds-style-switch";
  el.textContent = CSS;
  document.head.appendChild(el);
}

export function Switch({
  label,
  checked,
  defaultChecked,
  onChange,
  disabled = false,
  id,
  className = "",
  ...rest
}) {
  const reactId = React.useId();
  const swId = id || reactId;
  const classes = ["ds-switch", disabled ? "ds-switch--disabled" : "", className].filter(Boolean).join(" ");
  return (
    <label className={classes} htmlFor={swId}>
      <input
        id={swId}
        type="checkbox"
        role="switch"
        className="ds-switch__native"
        checked={checked}
        defaultChecked={defaultChecked}
        onChange={onChange}
        disabled={disabled}
        {...rest}
      />
      <span className="ds-switch__track"><span className="ds-switch__thumb" /></span>
      {label ? <span className="ds-switch__label">{label}</span> : null}
    </label>
  );
}

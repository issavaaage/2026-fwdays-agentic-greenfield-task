import React from "react";

/* Minimal inline glyphs (Lucide-style 1.75 stroke) so this control is
   self-contained. The UI kits use the full Lucide CDN set elsewhere. */
const SearchGlyph = () => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
    <circle cx="11" cy="11" r="7" /><path d="m21 21-4.3-4.3" />
  </svg>
);
const XGlyph = () => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
    <path d="M18 6 6 18M6 6l12 12" />
  </svg>
);

const CSS = `
.ds-search { position: relative; display: flex; align-items: center; width: 100%; }
.ds-search__input {
  width: 100%;
  height: var(--control-height-md);
  padding: 0 var(--space-9, 38px) 0 var(--space-10);
  font-family: var(--font-sans);
  font-size: var(--text-sm);
  color: var(--text-primary);
  background: var(--surface-card);
  border: 1px solid var(--border-default);
  border-radius: var(--radius-control);
  transition: border-color .15s ease, box-shadow .15s ease;
  appearance: none;
}
.ds-search__input::placeholder { color: var(--text-tertiary); }
.ds-search__input:hover:not(:disabled) { border-color: var(--ink-400); }
.ds-search__input:focus { outline: none; border-color: var(--ink-900); box-shadow: 0 0 0 1px var(--ink-900); }
.ds-search__input::-webkit-search-cancel-button { display: none; }
.ds-search--lg .ds-search__input { height: var(--control-height-lg); font-size: var(--text-base); }

.ds-search__icon {
  position: absolute; left: var(--space-3);
  display: inline-flex; align-items: center;
  color: var(--text-tertiary); pointer-events: none;
}
.ds-search__icon svg { width: 17px; height: 17px; }

.ds-search__clear {
  position: absolute; right: var(--space-2);
  display: inline-flex; align-items: center; justify-content: center;
  width: 26px; height: 26px;
  border: none; background: transparent; border-radius: var(--radius-sm);
  color: var(--text-tertiary); cursor: pointer;
  transition: background-color .12s ease, color .12s ease;
}
.ds-search__clear:hover { background: var(--surface-active); color: var(--text-primary); }
.ds-search__clear svg { width: 15px; height: 15px; }
`;

if (typeof document !== "undefined" && !document.getElementById("ds-style-search")) {
  const el = document.createElement("style");
  el.id = "ds-style-search";
  el.textContent = CSS;
  document.head.appendChild(el);
}

export function SearchInput({
  value = "",
  onChange,
  onClear,
  placeholder = "Search Pokémon…",
  size = "md",
  className = "",
  ...rest
}) {
  const classes = ["ds-search", size === "lg" ? "ds-search--lg" : "", className].filter(Boolean).join(" ");
  return (
    <div className={classes}>
      <span className="ds-search__icon"><SearchGlyph /></span>
      <input
        type="search"
        className="ds-search__input"
        value={value}
        onChange={onChange}
        placeholder={placeholder}
        aria-label={rest["aria-label"] || placeholder}
        {...rest}
      />
      {value ? (
        <button
          type="button"
          className="ds-search__clear"
          aria-label="Clear search"
          onClick={(e) => {
            if (onClear) onClear(e);
            else if (onChange) onChange({ target: { value: "" } });
          }}
        >
          <XGlyph />
        </button>
      ) : null}
    </div>
  );
}

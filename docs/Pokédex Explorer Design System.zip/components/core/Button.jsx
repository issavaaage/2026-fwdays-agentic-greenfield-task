import React from "react";

/* Inject component styles once. Uses design-system tokens from styles.css. */
const CSS = `
.ds-btn {
  --_h: var(--control-height-md);
  --_px: var(--space-4);
  --_fs: var(--text-sm);
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: var(--space-2);
  height: var(--_h);
  padding: 0 var(--_px);
  font-family: var(--font-sans);
  font-size: var(--_fs);
  font-weight: var(--weight-semibold);
  line-height: 1;
  letter-spacing: var(--tracking-tight);
  border-radius: var(--radius-control);
  border: 1px solid transparent;
  cursor: pointer;
  text-decoration: none;
  white-space: nowrap;
  transition: background-color .15s ease, border-color .15s ease, color .15s ease, transform .05s ease;
  user-select: none;
}
.ds-btn:active { transform: translateY(0.5px); }
.ds-btn:disabled, .ds-btn[aria-disabled="true"] {
  cursor: not-allowed;
  opacity: 0.45;
  transform: none;
}
.ds-btn--sm { --_h: var(--control-height-sm); --_px: var(--space-3); --_fs: var(--text-xs); }
.ds-btn--lg { --_h: var(--control-height-lg); --_px: var(--space-6); --_fs: var(--text-base); }
.ds-btn--full { width: 100%; }

/* Primary — ink fill */
.ds-btn--primary {
  background: var(--action-primary);
  color: var(--action-on-primary);
}
.ds-btn--primary:hover:not(:disabled):not([aria-disabled="true"]) { background: var(--action-primary-hover); }
.ds-btn--primary:active:not(:disabled) { background: var(--action-primary-active); }

/* Secondary — outline */
.ds-btn--secondary {
  background: var(--surface-card);
  color: var(--text-primary);
  border-color: var(--border-strong);
}
.ds-btn--secondary:hover:not(:disabled):not([aria-disabled="true"]) { background: var(--surface-hover); border-color: var(--ink-400); }
.ds-btn--secondary:active:not(:disabled) { background: var(--surface-active); }

/* Ghost — text only */
.ds-btn--ghost {
  background: transparent;
  color: var(--text-primary);
}
.ds-btn--ghost:hover:not(:disabled):not([aria-disabled="true"]) { background: var(--surface-hover); }
.ds-btn--ghost:active:not(:disabled) { background: var(--surface-active); }

.ds-btn svg { width: 1.05em; height: 1.05em; flex: none; }
`;

if (typeof document !== "undefined" && !document.getElementById("ds-style-button")) {
  const el = document.createElement("style");
  el.id = "ds-style-button";
  el.textContent = CSS;
  document.head.appendChild(el);
}

export function Button({
  variant = "primary",
  size = "md",
  fullWidth = false,
  disabled = false,
  iconLeft = null,
  iconRight = null,
  as = "button",
  href,
  className = "",
  children,
  ...rest
}) {
  const classes = [
    "ds-btn",
    `ds-btn--${variant}`,
    size !== "md" ? `ds-btn--${size}` : "",
    fullWidth ? "ds-btn--full" : "",
    className,
  ].filter(Boolean).join(" ");

  const content = (
    <>
      {iconLeft}
      {children ? <span>{children}</span> : null}
      {iconRight}
    </>
  );

  if (as === "a") {
    return (
      <a
        className={classes}
        href={disabled ? undefined : href}
        aria-disabled={disabled || undefined}
        {...rest}
      >
        {content}
      </a>
    );
  }

  return (
    <button className={classes} disabled={disabled} {...rest}>
      {content}
    </button>
  );
}

import React from "react";

const CSS = `
.ds-check { display: inline-flex; align-items: center; gap: var(--space-2-5, 10px); cursor: pointer; user-select: none; }
.ds-check--disabled { cursor: not-allowed; opacity: .5; }
.ds-check__box {
  position: relative;
  width: 18px; height: 18px; flex: none;
  border: 1.5px solid var(--border-strong);
  border-radius: var(--radius-xs);
  background: var(--surface-card);
  transition: background-color .12s ease, border-color .12s ease;
}
.ds-check__native { position: absolute; opacity: 0; width: 0; height: 0; }
.ds-check__box svg { position: absolute; inset: 0; width: 100%; height: 100%; color: var(--action-on-primary); opacity: 0; transform: scale(.6); transition: opacity .12s ease, transform .12s ease; }
.ds-check__native:checked + .ds-check__box { background: var(--action-primary); border-color: var(--action-primary); }
.ds-check__native:checked + .ds-check__box svg { opacity: 1; transform: scale(1); }
.ds-check:hover .ds-check__native:not(:checked):not(:disabled) + .ds-check__box { border-color: var(--ink-500); }
.ds-check__native:focus-visible + .ds-check__box { outline: 2px solid var(--focus-ring); outline-offset: 2px; }
.ds-check__label { font-size: var(--text-sm); color: var(--text-primary); }
`;

if (typeof document !== "undefined" && !document.getElementById("ds-style-check")) {
  const el = document.createElement("style");
  el.id = "ds-style-check";
  el.textContent = CSS;
  document.head.appendChild(el);
}

const CheckGlyph = () => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
    <path d="M20 6 9 17l-5-5" />
  </svg>
);

export function Checkbox({
  label,
  checked,
  defaultChecked,
  onChange,
  disabled = false,
  id,
  className = "",
  ...rest
}) {
  const reactId = React.useId();
  const cbId = id || reactId;
  const classes = ["ds-check", disabled ? "ds-check--disabled" : "", className].filter(Boolean).join(" ");
  return (
    <label className={classes} htmlFor={cbId}>
      <input
        id={cbId}
        type="checkbox"
        className="ds-check__native"
        checked={checked}
        defaultChecked={defaultChecked}
        onChange={onChange}
        disabled={disabled}
        {...rest}
      />
      <span className="ds-check__box"><CheckGlyph /></span>
      {label ? <span className="ds-check__label">{label}</span> : null}
    </label>
  );
}

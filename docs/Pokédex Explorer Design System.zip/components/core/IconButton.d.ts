import * as React from "react";

export type IconButtonSize = "sm" | "md" | "lg";
export type IconButtonVariant = "ghost" | "outline" | "solid";

/**
 * A square, icon-only button. Always requires an accessible `label`
 * (rendered as aria-label + title). Use for toolbar actions, clear/close,
 * and pagination arrows.
 */
export interface IconButtonProps
  extends Omit<React.ButtonHTMLAttributes<HTMLButtonElement>, "children"> {
  /** Accessible name — required for a11y. */
  label: string;
  /** @default "md" */
  size?: IconButtonSize;
  /** @default "ghost" */
  variant?: IconButtonVariant;
  disabled?: boolean;
  /** The icon element (e.g. a Lucide <svg>). */
  children?: React.ReactNode;
}

export function IconButton(props: IconButtonProps): React.ReactElement;

A calm, centered empty state for when search + filters match nothing. Never a blank screen.

```jsx
<EmptyState
  title="No Pokémon found"
  description="Try a different name or clear some filters."
  action={<Button variant="secondary" onClick={clear}>Clear filters</Button>}
/>
```

Defaults to a magnifier icon and "No Pokémon found". Pass `icon` to override.

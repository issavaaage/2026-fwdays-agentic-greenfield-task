import React from "react";

const CSS = `
.ds-empty {
  display: flex; flex-direction: column; align-items: center; text-align: center;
  gap: var(--space-3);
  padding: var(--space-16) var(--space-6);
  max-width: 420px; margin: 0 auto;
}
.ds-empty__icon {
  display: inline-flex; align-items: center; justify-content: center;
  width: 56px; height: 56px;
  border-radius: var(--radius-full);
  background: var(--surface-sunken);
  color: var(--text-tertiary);
  margin-bottom: var(--space-1);
}
.ds-empty__icon svg { width: 26px; height: 26px; }
.ds-empty__title {
  font-family: var(--font-sans);
  font-size: var(--text-lg);
  font-weight: var(--weight-bold);
  letter-spacing: var(--tracking-tight);
  color: var(--text-primary);
}
.ds-empty__desc { font-size: var(--text-sm); color: var(--text-secondary); line-height: var(--leading-normal); }
.ds-empty__actions { margin-top: var(--space-2); display: flex; gap: var(--space-2); }
`;

if (typeof document !== "undefined" && !document.getElementById("ds-style-empty")) {
  const el = document.createElement("style");
  el.id = "ds-style-empty";
  el.textContent = CSS;
  document.head.appendChild(el);
}

const DefaultGlyph = () => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
    <circle cx="11" cy="11" r="7" /><path d="m21 21-4.3-4.3" />
  </svg>
);

export function EmptyState({
  icon,
  title = "No Pokémon found",
  description,
  action,
  className = "",
  ...rest
}) {
  return (
    <div className={["ds-empty", className].filter(Boolean).join(" ")} {...rest}>
      <span className="ds-empty__icon">{icon || <DefaultGlyph />}</span>
      <div className="ds-empty__title">{title}</div>
      {description ? <div className="ds-empty__desc">{description}</div> : null}
      {action ? <div className="ds-empty__actions">{action}</div> : null}
    </div>
  );
}

import * as React from "react";

/**
 * A calm, centered empty state (FR-LIST-04) shown when search + filters match
 * nothing. Pairs a soft icon medallion with a title, optional description,
 * and an optional action (typically a "Clear filters" button).
 */
export interface EmptyStateProps extends React.HTMLAttributes<HTMLDivElement> {
  /** Icon element; defaults to a magnifier. */
  icon?: React.ReactNode;
  /** @default "No Pokémon found" */
  title?: string;
  description?: string;
  /** Action node, e.g. a <Button>. */
  action?: React.ReactNode;
}

export function EmptyState(props: EmptyStateProps): React.ReactElement;

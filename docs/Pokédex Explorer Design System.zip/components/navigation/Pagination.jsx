import React from "react";

const CSS = `
.ds-pager { display: inline-flex; align-items: center; gap: var(--space-1-5); }
.ds-pager__btn {
  min-width: 36px; height: 36px;
  display: inline-flex; align-items: center; justify-content: center;
  padding: 0 var(--space-2);
  font-family: var(--font-mono);
  font-size: var(--text-sm);
  font-variant-numeric: tabular-nums;
  color: var(--text-secondary);
  background: var(--surface-card);
  border: 1px solid var(--border-default);
  border-radius: var(--radius-control);
  cursor: pointer;
  transition: background-color .12s ease, border-color .12s ease, color .12s ease;
}
.ds-pager__btn:hover:not(:disabled):not([aria-current="page"]) { background: var(--surface-hover); border-color: var(--ink-400); color: var(--text-primary); }
.ds-pager__btn:disabled { opacity: .4; cursor: not-allowed; }
.ds-pager__btn[aria-current="page"] { background: var(--action-primary); border-color: var(--action-primary); color: var(--action-on-primary); cursor: default; }
.ds-pager__btn svg { width: 16px; height: 16px; }
.ds-pager__ellipsis { min-width: 24px; text-align: center; color: var(--text-tertiary); font-family: var(--font-mono); font-size: var(--text-sm); }
`;

if (typeof document !== "undefined" && !document.getElementById("ds-style-pager")) {
  const el = document.createElement("style");
  el.id = "ds-style-pager";
  el.textContent = CSS;
  document.head.appendChild(el);
}

const ChevL = () => (<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round"><path d="m15 18-6-6 6-6"/></svg>);
const ChevR = () => (<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round"><path d="m9 18 6-6-6-6"/></svg>);

/** Build a compact page-number model with ellipses. */
function pageModel(current, total, siblings = 1) {
  const out = [];
  const push = (v) => out.push(v);
  const left = Math.max(2, current - siblings);
  const right = Math.min(total - 1, current + siblings);
  push(1);
  if (left > 2) push("…");
  for (let p = left; p <= right; p++) push(p);
  if (right < total - 1) push("…");
  if (total > 1) push(total);
  return out;
}

export function Pagination({
  page = 1,
  totalPages = 1,
  onPageChange,
  siblingCount = 1,
  className = "",
  ...rest
}) {
  const go = (p) => { if (onPageChange && p >= 1 && p <= totalPages && p !== page) onPageChange(p); };
  const model = pageModel(page, totalPages, siblingCount);
  return (
    <nav className={["ds-pager", className].filter(Boolean).join(" ")} aria-label="Pagination" {...rest}>
      <button className="ds-pager__btn" aria-label="Previous page" disabled={page <= 1} onClick={() => go(page - 1)}><ChevL /></button>
      {model.map((p, i) =>
        p === "…"
          ? <span key={`e${i}`} className="ds-pager__ellipsis">…</span>
          : <button
              key={p}
              className="ds-pager__btn"
              aria-current={p === page ? "page" : undefined}
              onClick={() => go(p)}
            >{p}</button>
      )}
      <button className="ds-pager__btn" aria-label="Next page" disabled={page >= totalPages} onClick={() => go(page + 1)}><ChevR /></button>
    </nav>
  );
}

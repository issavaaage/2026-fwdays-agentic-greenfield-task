import * as React from "react";

/**
 * Bottom-of-list pagination (FR-PAGE-01): previous, numbered pages with
 * ellipsis collapsing, and next. The current page reads as a solid ink
 * button. Numbers are mono/tabular so widths stay stable.
 */
export interface PaginationProps
  extends Omit<React.HTMLAttributes<HTMLElement>, "onChange"> {
  /** Current 1-based page. */
  page: number;
  /** Total number of pages. */
  totalPages: number;
  /** Called with the requested page. */
  onPageChange?: (page: number) => void;
  /** Pages shown either side of the current one. @default 1 */
  siblingCount?: number;
}

export function Pagination(props: PaginationProps): React.ReactElement;

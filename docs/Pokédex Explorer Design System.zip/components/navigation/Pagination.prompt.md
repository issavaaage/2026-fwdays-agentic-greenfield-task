Bottom-of-list pagination with previous/next arrows and numbered pages that collapse to ellipses. The current page is a solid ink button.

```jsx
<Pagination page={page} totalPages={52} onPageChange={setPage} />
```

Numbers are mono/tabular for stable widths. Keep the current page in the URL as `?page=` (FR-PAGE-02).

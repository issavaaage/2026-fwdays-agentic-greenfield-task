---
name: pokedex-explorer-design
description: Use this skill to generate well-branded interfaces and assets for Pokédex Explorer, either for production or throwaway prototypes/mocks/etc. Contains essential design guidelines, colors, type, fonts, assets, and UI kit components for prototyping.
user-invocable: true
---

Read the `readme.md` file within this skill, and explore the other available files.

If creating visual artifacts (slides, mocks, throwaway prototypes, etc), copy assets out and create static HTML files for the user to view. If working on production code, you can copy assets and read the rules here to become an expert in designing with this brand.

If the user invokes this skill without any other guidance, ask them what they want to build or design, ask some questions, and act as an expert designer who outputs HTML artifacts _or_ production code, depending on the need.

## Quick orientation

- **Brand:** Pokédex Explorer — a clean, privacy-first Pokédex browser. Restrained, editorial, **near-monochrome**; the Pokémon artwork is the only real color. The 18 type colors appear only as small badges.
- **Type:** Hanken Grotesk (prose/headings) + JetBrains Mono (dex numbers, stats, labels). Sentence case in sans; UPPERCASE + wide tracking in mono.
- **Tone:** plain, calm, factual. No hype, no emoji, no mascot.

## Files

- `styles.css` — single CSS entry point; `@import`s all tokens + fonts. Link this one file.
- `tokens/` — color, type-color, typography, spacing, radius, shadow, base CSS variables.
- `components/` — React primitives (Button, IconButton, Input, SearchInput, Select, Checkbox, Switch, Badge, TypeBadge, Card, PokemonCard, StatBar, Pagination, EmptyState). Each has `.jsx` + `.d.ts` + `.prompt.md` + a `.card.html` showcase.
- `guidelines/` — foundation specimen cards (color/type/spacing/brand).
- `ui_kits/explorer/` — interactive recreation of the full two-screen app (list + detail).

## Working with this system

- **Color:** use the `--ink-*` neutral ramp and semantic tokens (`--text-primary`, `--surface-card`, `--border-subtle`, …). Don't introduce new accent colors. Type color only via `TypeBadge` / `--type-<t>-*` tokens.
- **Icons:** Lucide, 1.75 stroke, `currentColor`. No emoji.
- **Components:** read `<Name>.prompt.md` for usage. In standalone HTML, link `styles.css`, load `_ds_bundle.js`, then `const { X } = window.<Namespace>` (run `check_design_system` for the exact namespace). Never `<script src>` a `.jsx` directly.
- **Artwork:** official artwork loads from the PokéAPI sprites CDN by dex id — see `artworkUrl(id)` exported from `PokemonCard`.

Always cross-reference `readme.md` for the full content + visual foundations before producing anything.

# Pokédex Explorer — Design System

A small, opinionated design system for **Pokémon Explorer**, a clean,
privacy-first web app for browsing the Pokédex. Search by name, narrow by type
/ generation / legendary status, and open any Pokémon for its full profile.

This system was authored **greenfield**: the source project ships no prior
visual design (see Sources), so the brand below was designed from the product
brief, not reverse-engineered from an existing UI.

---

## Sources

- **Codebase:** `2026-fwdays-agentic-greenfield-task/` (mounted locally).
  A near-empty Next.js 16 / React 19 / Tailwind 4 starter. The only design
  inputs were the product docs; `app/page.tsx` was the unmodified CRA splash.
- **Product brief:** `2026-fwdays-agentic-greenfield-task/docs/product-brief.md`
- **Requirements (source of truth):** `2026-fwdays-agentic-greenfield-task/docs/requirements.md`
  — numbered FR/NFR/TC/BC requirements; this system maps to them throughout.
- **Data:** [PokéAPI](https://pokeapi.co) (keyless). Official artwork is loaded
  from the public PokéAPI sprites CDN by dex id.

> The reader is not assumed to have access to these; links/paths are recorded
> in case they do.

---

## Product context

- **One actor:** an anonymous, curious visitor. No accounts, cookies, trackers,
  or personalization (BC-PRIVACY-01/02).
- **Two screens:** a list (search + filters + paginated grid) and a detail page.
- **Operating principles:** privacy-first, keyless/free, honest under failure,
  and clean/minimal — *content-first, no decorative chrome* (BC-BRAND-01).

The design system exists to make those two screens, and anything adjacent
(slides, mocks, marketing), feel like one calm, editorial product.

---

## Design system at a glance

- **Personality:** restrained & editorial. The UI is near-monochrome; **the
  Pokémon artwork is the only real color** on a typical screen.
- **Type color:** the 18 canonical type hues appear *only* as small badges.
- **Type pairing:** Hanken Grotesk (prose/headings) + JetBrains Mono (data —
  dex numbers, stat values, labels). The sans/mono contrast is the signature.
- **Light only.**

---

## CONTENT FUNDAMENTALS

How copy is written across the product.

- **Voice:** plain, calm, factual. The product gets out of the way. No hype,
  no mascot persona, no jokes.
- **Person:** second person, implied. Address the visitor through their task,
  not flattery. "Search the dex." "Back to results." "Clear filters."
- **Casing:** **sentence case** everywhere — headings, buttons, labels. The one
  exception is the **mono register**, which is UPPERCASE with wide tracking
  (`--tracking-wider`): eyebrow labels (`SEARCH`, `BASE STATS`, `HEIGHT`) and
  type names in badges (`FIRE`, `WATER`).
- **Numbers are mono.** Dex numbers are always zero-padded to four digits with
  a leading hash: `#0006`, `#0025`, `#0151`. Stats, height (m), and weight (kg)
  are mono/tabular.
- **Honest states.** Empty and error states name what happened plainly:
  "No Pokémon found" / "Nothing matches your current search and filters." Never
  a blank screen, never a cute error voice.
- **Quiet attribution.** "Data from PokéAPI" in the footer — credited, not
  promoted (BC-BRAND-02).
- **No emoji.** Not in UI, not in copy. Iconography is Lucide (see below).

**Examples**

| Do | Don't |
| --- | --- |
| Search the dex | Catch 'em all NOW!! |
| No Pokémon found | Oops! Nothing here 😅 |
| Legendary | ✨ LEGENDARY ✨ |
| Data from PokéAPI | Powered by the amazing PokéAPI! |

---

## VISUAL FOUNDATIONS

**Color.** Near-monochrome. A single warm-gray neutral ramp (`--ink-0` → 
`--ink-950`) drives every surface, text, and border; the page sits on a faintly
warm paper (`--paper`). There is **no brand accent color** — the primary action
is ink-black. The only chromatic color is the 18-hue Pokémon type palette, used
exclusively in small badges as soft tinted backgrounds with a darkened-hue label
(derived via `color-mix` for WCAG AA). One metallic accent (`--legendary`) marks
legendary/mythical. Status red/green exist for danger/success but are rare.
Imagery (official artwork) is full-color on a near-white radial pedestal, so it
pops against the gray UI.

**Type.** Hanken Grotesk for everything human-readable; JetBrains Mono for
everything "machine" (numbers, labels, codes). Display is extrabold (800) with
tight tracking (`-0.03em`); headings bold (700); body regular at 1.5–1.6 line
height. Mono labels are 11–12px, uppercase, `+0.08em` tracking. Generous scale:
the detail name is 60px; nothing functional drops below ~12px.

**Spacing & layout.** 4px base grid. Centered content column, `--container-max`
1240px. Responsive grid per FR-SHELL-02: 1 col (mobile) → 2 (≤1024) → 3 (≤1280)
→ 4 (desktop). Filters sit in an open stack above the results; results live in a
soft bordered panel.

**Backgrounds.** No gradients-as-decoration, no patterns, no textures, no
hero imagery. The one gradient is a subtle near-white radial *pedestal* behind
artwork. The top bar uses a translucent paper fill + light backdrop blur when
it sticks — the only use of blur/transparency in the system.

**Corners.** Restrained: controls/inputs 8px (`--radius-control`), cards 12px
(`--radius-card`), larger panels 16–20px, badges/pills fully round.

**Borders vs shadows.** Editorial UI leans on **borders**, not elevation.
Cards rest with a 1px subtle border and a *whisper* shadow (`--shadow-xs`);
elevation only deepens on hover (`--shadow-md`) and for overlays. No heavy
drop shadows, no colored glows.

**Cards.** White surface, 1px `--border-subtle`, 12px radius, `--shadow-xs`.
Interactive cards lift 2px and deepen their border + shadow on hover; the
artwork inside scales 1.05×. Focus shows a 2px ink outline with 2px offset.

**Animation.** Minimal and quick. 120–200ms ease transitions on color, border,
and transform. Stat bars fill with a 500ms ease. No bounces, no infinite loops,
no parallax. Respects the calm tone.

**Hover / press.** Hover = a step up the neutral ramp (e.g. surface → 
`--surface-hover`, border → `--ink-400`); primary buttons darken
(900 → 800). Press = a darker step (`--surface-active`, 900 → 950) and a 0.5px
nudge down for buttons. No scale-on-press except artwork.

**Focus.** Monochrome and unmistakable: `2px solid --ink-900` outline, 2px
offset (NFR-A11Y-01). Form controls also show a 1px ink ring on focus.

**Transparency & blur.** Used once: the sticky top bar
(`color-mix` paper + `backdrop-filter: blur`). Everywhere else is opaque.

**Imagery vibe.** Official Pokémon artwork — saturated, full-color, drop-shadowed
on a neutral pedestal. It is intentionally the loudest thing on screen.

---

## ICONOGRAPHY

- **Set:** [Lucide](https://lucide.dev) — the single icon system. Clean,
  consistent **1.75 stroke**, `currentColor`, 24×24 viewBox. No fills, no
  duotone, no second set.
- **Why Lucide:** the source codebase ships no icon font or SVG set (only the
  unrelated Next/Vercel logos), so Lucide was chosen as the closest match to the
  editorial, hairline-stroke aesthetic. *Substitution flagged — if you have a
  preferred set, say so.*
- **Delivery:** specimen card loads Lucide from CDN
  (`unpkg.com/lucide@0.460.0`); the UI kit inlines the exact path data it needs
  in `ui_kits/explorer/icons.jsx` (`window.PokeIcons`) so icons survive React
  re-renders. A few primitives (search, ×, chevrons, check) inline their own
  glyphs to stay dependency-free.
- **Common glyphs:** `search`, `x`, `sliders-horizontal`, `chevron-left/right`,
  `chevron-down`, `arrow-left`, `ruler`, `weight`, `sparkles`, `layers`,
  `layout-grid`, `list`, `filter`.
- **No emoji. No Unicode-as-icon** (except the `#` dex prefix, which is type, not
  an icon). **No mascot or Pokéball mark** — the wordmark is purely typographic.

---

## INDEX — what's in this project

**Root**
- `styles.css` — the single entry point consumers link. `@import`s only.
- `readme.md` — this guide.
- `SKILL.md` — Agent-Skill manifest for downloading/using this system.

**`tokens/`** — CSS custom properties (all reachable from `styles.css`)
- `fonts.css` · `colors.css` · `type-colors.css` · `typography.css` ·
  `spacing.css` · `radius.css` · `shadows.css` · `base.css`

**`components/`** — reusable React primitives (`window.<Namespace>`)
- `core/` — Button, IconButton, Input, SearchInput, Select, Checkbox, Switch
- `data-display/` — Badge, TypeBadge, Card, PokemonCard, StatBar
- `navigation/` — Pagination
- `feedback/` — EmptyState

Each component dir has `<Name>.jsx`, `<Name>.d.ts`, `<Name>.prompt.md`, and a
`*.card.html` showcase.

**`guidelines/`** — foundation specimen cards (Design System tab)
- Colors, Typography, Spacing, Brand groups.

**`ui_kits/explorer/`** — the interactive Pokémon Explorer recreation
- `index.html` (entry), `data.js`, `icons.jsx`, `AppShell.jsx`, `FilterBar.jsx`,
  `ListScreen.jsx`, `DetailScreen.jsx`, `README.md`.

---

## Using the components

In any `@dsCard` HTML, link `styles.css`, load `_ds_bundle.js`, then read from
the namespace (run `check_design_system` to confirm the exact name):

```html
<link rel="stylesheet" href="styles.css" />
<script src="_ds_bundle.js"></script>
<script type="text/babel">
  const { Button, TypeBadge, PokemonCard } = window.PokDexExplorerDesignSystem_6555a0;
</script>
```

Do **not** `<script src>` a component's `.jsx` directly — its `export` is only
reachable through the compiled bundle.

/* @ds-bundle: {"format":3,"namespace":"PokDexExplorerDesignSystem_6555a0","components":[{"name":"Button","sourcePath":"components/core/Button.jsx"},{"name":"Checkbox","sourcePath":"components/core/Checkbox.jsx"},{"name":"IconButton","sourcePath":"components/core/IconButton.jsx"},{"name":"Input","sourcePath":"components/core/Input.jsx"},{"name":"SearchInput","sourcePath":"components/core/SearchInput.jsx"},{"name":"Select","sourcePath":"components/core/Select.jsx"},{"name":"Switch","sourcePath":"components/core/Switch.jsx"},{"name":"Badge","sourcePath":"components/data-display/Badge.jsx"},{"name":"Card","sourcePath":"components/data-display/Card.jsx"},{"name":"PokemonCard","sourcePath":"components/data-display/PokemonCard.jsx"},{"name":"StatBar","sourcePath":"components/data-display/StatBar.jsx"},{"name":"POKEMON_TYPES","sourcePath":"components/data-display/TypeBadge.jsx"},{"name":"TypeBadge","sourcePath":"components/data-display/TypeBadge.jsx"},{"name":"EmptyState","sourcePath":"components/feedback/EmptyState.jsx"},{"name":"Pagination","sourcePath":"components/navigation/Pagination.jsx"}],"sourceHashes":{"components/core/Button.jsx":"289dce3b02c8","components/core/Checkbox.jsx":"c26b3cc83414","components/core/IconButton.jsx":"c1481473d5dd","components/core/Input.jsx":"35fa68d0b04c","components/core/SearchInput.jsx":"b976b373439a","components/core/Select.jsx":"9cf6c6c9750a","components/core/Switch.jsx":"fe4201a82701","components/data-display/Badge.jsx":"998e746d6df4","components/data-display/Card.jsx":"5c7df27f54a5","components/data-display/PokemonCard.jsx":"9db4df9d59e9","components/data-display/StatBar.jsx":"36dfcc06a840","components/data-display/TypeBadge.jsx":"f42dcd1e2865","components/feedback/EmptyState.jsx":"20de2f1e32c7","components/navigation/Pagination.jsx":"137eccd1592b","ui_kits/explorer/AppShell.jsx":"80369ffad6cf","ui_kits/explorer/DetailScreen.jsx":"300e364898ce","ui_kits/explorer/FilterBar.jsx":"0480562bd20b","ui_kits/explorer/ListScreen.jsx":"92608471b1f1","ui_kits/explorer/data.js":"04fa88debac0","ui_kits/explorer/icons.jsx":"e89c13281b30"},"inlinedExternals":[],"unexposedExports":[{"name":"artworkUrl","sourcePath":"components/data-display/PokemonCard.jsx"}]} */

(() => {

const __ds_ns = (window.PokDexExplorerDesignSystem_6555a0 = window.PokDexExplorerDesignSystem_6555a0 || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/core/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/* Inject component styles once. Uses design-system tokens from styles.css. */
const CSS = `
.ds-btn {
  --_h: var(--control-height-md);
  --_px: var(--space-4);
  --_fs: var(--text-sm);
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: var(--space-2);
  height: var(--_h);
  padding: 0 var(--_px);
  font-family: var(--font-sans);
  font-size: var(--_fs);
  font-weight: var(--weight-semibold);
  line-height: 1;
  letter-spacing: var(--tracking-tight);
  border-radius: var(--radius-control);
  border: 1px solid transparent;
  cursor: pointer;
  text-decoration: none;
  white-space: nowrap;
  transition: background-color .15s ease, border-color .15s ease, color .15s ease, transform .05s ease;
  user-select: none;
}
.ds-btn:active { transform: translateY(0.5px); }
.ds-btn:disabled, .ds-btn[aria-disabled="true"] {
  cursor: not-allowed;
  opacity: 0.45;
  transform: none;
}
.ds-btn--sm { --_h: var(--control-height-sm); --_px: var(--space-3); --_fs: var(--text-xs); }
.ds-btn--lg { --_h: var(--control-height-lg); --_px: var(--space-6); --_fs: var(--text-base); }
.ds-btn--full { width: 100%; }

/* Primary — ink fill */
.ds-btn--primary {
  background: var(--action-primary);
  color: var(--action-on-primary);
}
.ds-btn--primary:hover:not(:disabled):not([aria-disabled="true"]) { background: var(--action-primary-hover); }
.ds-btn--primary:active:not(:disabled) { background: var(--action-primary-active); }

/* Secondary — outline */
.ds-btn--secondary {
  background: var(--surface-card);
  color: var(--text-primary);
  border-color: var(--border-strong);
}
.ds-btn--secondary:hover:not(:disabled):not([aria-disabled="true"]) { background: var(--surface-hover); border-color: var(--ink-400); }
.ds-btn--secondary:active:not(:disabled) { background: var(--surface-active); }

/* Ghost — text only */
.ds-btn--ghost {
  background: transparent;
  color: var(--text-primary);
}
.ds-btn--ghost:hover:not(:disabled):not([aria-disabled="true"]) { background: var(--surface-hover); }
.ds-btn--ghost:active:not(:disabled) { background: var(--surface-active); }

.ds-btn svg { width: 1.05em; height: 1.05em; flex: none; }
`;
if (typeof document !== "undefined" && !document.getElementById("ds-style-button")) {
  const el = document.createElement("style");
  el.id = "ds-style-button";
  el.textContent = CSS;
  document.head.appendChild(el);
}
function Button({
  variant = "primary",
  size = "md",
  fullWidth = false,
  disabled = false,
  iconLeft = null,
  iconRight = null,
  as = "button",
  href,
  className = "",
  children,
  ...rest
}) {
  const classes = ["ds-btn", `ds-btn--${variant}`, size !== "md" ? `ds-btn--${size}` : "", fullWidth ? "ds-btn--full" : "", className].filter(Boolean).join(" ");
  const content = /*#__PURE__*/React.createElement(React.Fragment, null, iconLeft, children ? /*#__PURE__*/React.createElement("span", null, children) : null, iconRight);
  if (as === "a") {
    return /*#__PURE__*/React.createElement("a", _extends({
      className: classes,
      href: disabled ? undefined : href,
      "aria-disabled": disabled || undefined
    }, rest), content);
  }
  return /*#__PURE__*/React.createElement("button", _extends({
    className: classes,
    disabled: disabled
  }, rest), content);
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Button.jsx", error: String((e && e.message) || e) }); }

// components/core/Checkbox.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const CSS = `
.ds-check { display: inline-flex; align-items: center; gap: var(--space-2-5, 10px); cursor: pointer; user-select: none; }
.ds-check--disabled { cursor: not-allowed; opacity: .5; }
.ds-check__box {
  position: relative;
  width: 18px; height: 18px; flex: none;
  border: 1.5px solid var(--border-strong);
  border-radius: var(--radius-xs);
  background: var(--surface-card);
  transition: background-color .12s ease, border-color .12s ease;
}
.ds-check__native { position: absolute; opacity: 0; width: 0; height: 0; }
.ds-check__box svg { position: absolute; inset: 0; width: 100%; height: 100%; color: var(--action-on-primary); opacity: 0; transform: scale(.6); transition: opacity .12s ease, transform .12s ease; }
.ds-check__native:checked + .ds-check__box { background: var(--action-primary); border-color: var(--action-primary); }
.ds-check__native:checked + .ds-check__box svg { opacity: 1; transform: scale(1); }
.ds-check:hover .ds-check__native:not(:checked):not(:disabled) + .ds-check__box { border-color: var(--ink-500); }
.ds-check__native:focus-visible + .ds-check__box { outline: 2px solid var(--focus-ring); outline-offset: 2px; }
.ds-check__label { font-size: var(--text-sm); color: var(--text-primary); }
`;
if (typeof document !== "undefined" && !document.getElementById("ds-style-check")) {
  const el = document.createElement("style");
  el.id = "ds-style-check";
  el.textContent = CSS;
  document.head.appendChild(el);
}
const CheckGlyph = () => /*#__PURE__*/React.createElement("svg", {
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: "3",
  strokeLinecap: "round",
  strokeLinejoin: "round",
  "aria-hidden": "true"
}, /*#__PURE__*/React.createElement("path", {
  d: "M20 6 9 17l-5-5"
}));
function Checkbox({
  label,
  checked,
  defaultChecked,
  onChange,
  disabled = false,
  id,
  className = "",
  ...rest
}) {
  const reactId = React.useId();
  const cbId = id || reactId;
  const classes = ["ds-check", disabled ? "ds-check--disabled" : "", className].filter(Boolean).join(" ");
  return /*#__PURE__*/React.createElement("label", {
    className: classes,
    htmlFor: cbId
  }, /*#__PURE__*/React.createElement("input", _extends({
    id: cbId,
    type: "checkbox",
    className: "ds-check__native",
    checked: checked,
    defaultChecked: defaultChecked,
    onChange: onChange,
    disabled: disabled
  }, rest)), /*#__PURE__*/React.createElement("span", {
    className: "ds-check__box"
  }, /*#__PURE__*/React.createElement(CheckGlyph, null)), label ? /*#__PURE__*/React.createElement("span", {
    className: "ds-check__label"
  }, label) : null);
}
Object.assign(__ds_scope, { Checkbox });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Checkbox.jsx", error: String((e && e.message) || e) }); }

// components/core/IconButton.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const CSS = `
.ds-iconbtn {
  --_s: var(--control-height-md);
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: var(--_s);
  height: var(--_s);
  padding: 0;
  border-radius: var(--radius-control);
  border: 1px solid transparent;
  background: transparent;
  color: var(--text-secondary);
  cursor: pointer;
  transition: background-color .15s ease, border-color .15s ease, color .15s ease;
}
.ds-iconbtn:hover:not(:disabled) { background: var(--surface-hover); color: var(--text-primary); }
.ds-iconbtn:active:not(:disabled) { background: var(--surface-active); }
.ds-iconbtn:disabled { opacity: .4; cursor: not-allowed; }
.ds-iconbtn--sm { --_s: var(--control-height-sm); }
.ds-iconbtn--lg { --_s: var(--control-height-lg); }
.ds-iconbtn--outline { border-color: var(--border-default); background: var(--surface-card); }
.ds-iconbtn--outline:hover:not(:disabled) { border-color: var(--ink-400); }
.ds-iconbtn--solid { background: var(--action-primary); color: var(--action-on-primary); }
.ds-iconbtn--solid:hover:not(:disabled) { background: var(--action-primary-hover); }
.ds-iconbtn svg { width: 1.15em; height: 1.15em; }
`;
if (typeof document !== "undefined" && !document.getElementById("ds-style-iconbtn")) {
  const el = document.createElement("style");
  el.id = "ds-style-iconbtn";
  el.textContent = CSS;
  document.head.appendChild(el);
}
function IconButton({
  size = "md",
  variant = "ghost",
  label,
  disabled = false,
  className = "",
  children,
  ...rest
}) {
  const classes = ["ds-iconbtn", size !== "md" ? `ds-iconbtn--${size}` : "", variant !== "ghost" ? `ds-iconbtn--${variant}` : "", className].filter(Boolean).join(" ");
  return /*#__PURE__*/React.createElement("button", _extends({
    className: classes,
    "aria-label": label,
    title: label,
    disabled: disabled
  }, rest), children);
}
Object.assign(__ds_scope, { IconButton });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/IconButton.jsx", error: String((e && e.message) || e) }); }

// components/core/Input.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const CSS = `
.ds-field { display: flex; flex-direction: column; gap: var(--space-1-5); }
.ds-field__label {
  font-family: var(--font-mono);
  font-size: var(--text-2xs);
  font-weight: var(--weight-medium);
  letter-spacing: var(--tracking-wider);
  text-transform: uppercase;
  color: var(--text-tertiary);
}
.ds-field__hint { font-size: var(--text-xs); color: var(--text-tertiary); }
.ds-field__hint--error { color: var(--danger); }

.ds-input-wrap { position: relative; display: flex; align-items: center; }
.ds-input {
  width: 100%;
  height: var(--control-height-md);
  padding: 0 var(--space-3);
  font-family: var(--font-sans);
  font-size: var(--text-sm);
  color: var(--text-primary);
  background: var(--surface-card);
  border: 1px solid var(--border-default);
  border-radius: var(--radius-control);
  transition: border-color .15s ease, box-shadow .15s ease;
  appearance: none;
}
.ds-input::placeholder { color: var(--text-tertiary); }
.ds-input:hover:not(:disabled) { border-color: var(--ink-400); }
.ds-input:focus { outline: none; border-color: var(--ink-900); box-shadow: 0 0 0 1px var(--ink-900); }
.ds-input:disabled { background: var(--surface-sunken); color: var(--text-disabled); cursor: not-allowed; }
.ds-input--error { border-color: var(--danger); }
.ds-input--error:focus { box-shadow: 0 0 0 1px var(--danger); border-color: var(--danger); }
.ds-input--sm { height: var(--control-height-sm); font-size: var(--text-xs); }
.ds-input--lg { height: var(--control-height-lg); font-size: var(--text-base); }
.ds-input--with-icon-left { padding-left: var(--space-10); }
.ds-input--with-icon-right { padding-right: var(--space-10); }

.ds-input-icon {
  position: absolute;
  display: inline-flex;
  align-items: center;
  color: var(--text-tertiary);
  pointer-events: none;
}
.ds-input-icon--left { left: var(--space-3); }
.ds-input-icon--right { right: var(--space-3); }
.ds-input-icon svg { width: 16px; height: 16px; }
`;
if (typeof document !== "undefined" && !document.getElementById("ds-style-input")) {
  const el = document.createElement("style");
  el.id = "ds-style-input";
  el.textContent = CSS;
  document.head.appendChild(el);
}
function Input({
  label,
  hint,
  error,
  size = "md",
  iconLeft = null,
  iconRight = null,
  id,
  className = "",
  ...rest
}) {
  const reactId = React.useId();
  const inputId = id || reactId;
  const inputClasses = ["ds-input", size !== "md" ? `ds-input--${size}` : "", error ? "ds-input--error" : "", iconLeft ? "ds-input--with-icon-left" : "", iconRight ? "ds-input--with-icon-right" : "", className].filter(Boolean).join(" ");
  const field = /*#__PURE__*/React.createElement("div", {
    className: "ds-input-wrap"
  }, iconLeft ? /*#__PURE__*/React.createElement("span", {
    className: "ds-input-icon ds-input-icon--left"
  }, iconLeft) : null, /*#__PURE__*/React.createElement("input", _extends({
    id: inputId,
    className: inputClasses,
    "aria-invalid": error ? true : undefined
  }, rest)), iconRight ? /*#__PURE__*/React.createElement("span", {
    className: "ds-input-icon ds-input-icon--right"
  }, iconRight) : null);
  if (!label && !hint && !error) return field;
  return /*#__PURE__*/React.createElement("div", {
    className: "ds-field"
  }, label ? /*#__PURE__*/React.createElement("label", {
    className: "ds-field__label",
    htmlFor: inputId
  }, label) : null, field, error ? /*#__PURE__*/React.createElement("span", {
    className: "ds-field__hint ds-field__hint--error"
  }, error) : hint ? /*#__PURE__*/React.createElement("span", {
    className: "ds-field__hint"
  }, hint) : null);
}
Object.assign(__ds_scope, { Input });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Input.jsx", error: String((e && e.message) || e) }); }

// components/core/SearchInput.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/* Minimal inline glyphs (Lucide-style 1.75 stroke) so this control is
   self-contained. The UI kits use the full Lucide CDN set elsewhere. */
const SearchGlyph = () => /*#__PURE__*/React.createElement("svg", {
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: "1.75",
  strokeLinecap: "round",
  strokeLinejoin: "round",
  "aria-hidden": "true"
}, /*#__PURE__*/React.createElement("circle", {
  cx: "11",
  cy: "11",
  r: "7"
}), /*#__PURE__*/React.createElement("path", {
  d: "m21 21-4.3-4.3"
}));
const XGlyph = () => /*#__PURE__*/React.createElement("svg", {
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: "1.75",
  strokeLinecap: "round",
  strokeLinejoin: "round",
  "aria-hidden": "true"
}, /*#__PURE__*/React.createElement("path", {
  d: "M18 6 6 18M6 6l12 12"
}));
const CSS = `
.ds-search { position: relative; display: flex; align-items: center; width: 100%; }
.ds-search__input {
  width: 100%;
  height: var(--control-height-md);
  padding: 0 var(--space-9, 38px) 0 var(--space-10);
  font-family: var(--font-sans);
  font-size: var(--text-sm);
  color: var(--text-primary);
  background: var(--surface-card);
  border: 1px solid var(--border-default);
  border-radius: var(--radius-control);
  transition: border-color .15s ease, box-shadow .15s ease;
  appearance: none;
}
.ds-search__input::placeholder { color: var(--text-tertiary); }
.ds-search__input:hover:not(:disabled) { border-color: var(--ink-400); }
.ds-search__input:focus { outline: none; border-color: var(--ink-900); box-shadow: 0 0 0 1px var(--ink-900); }
.ds-search__input::-webkit-search-cancel-button { display: none; }
.ds-search--lg .ds-search__input { height: var(--control-height-lg); font-size: var(--text-base); }

.ds-search__icon {
  position: absolute; left: var(--space-3);
  display: inline-flex; align-items: center;
  color: var(--text-tertiary); pointer-events: none;
}
.ds-search__icon svg { width: 17px; height: 17px; }

.ds-search__clear {
  position: absolute; right: var(--space-2);
  display: inline-flex; align-items: center; justify-content: center;
  width: 26px; height: 26px;
  border: none; background: transparent; border-radius: var(--radius-sm);
  color: var(--text-tertiary); cursor: pointer;
  transition: background-color .12s ease, color .12s ease;
}
.ds-search__clear:hover { background: var(--surface-active); color: var(--text-primary); }
.ds-search__clear svg { width: 15px; height: 15px; }
`;
if (typeof document !== "undefined" && !document.getElementById("ds-style-search")) {
  const el = document.createElement("style");
  el.id = "ds-style-search";
  el.textContent = CSS;
  document.head.appendChild(el);
}
function SearchInput({
  value = "",
  onChange,
  onClear,
  placeholder = "Search Pokémon…",
  size = "md",
  className = "",
  ...rest
}) {
  const classes = ["ds-search", size === "lg" ? "ds-search--lg" : "", className].filter(Boolean).join(" ");
  return /*#__PURE__*/React.createElement("div", {
    className: classes
  }, /*#__PURE__*/React.createElement("span", {
    className: "ds-search__icon"
  }, /*#__PURE__*/React.createElement(SearchGlyph, null)), /*#__PURE__*/React.createElement("input", _extends({
    type: "search",
    className: "ds-search__input",
    value: value,
    onChange: onChange,
    placeholder: placeholder,
    "aria-label": rest["aria-label"] || placeholder
  }, rest)), value ? /*#__PURE__*/React.createElement("button", {
    type: "button",
    className: "ds-search__clear",
    "aria-label": "Clear search",
    onClick: e => {
      if (onClear) onClear(e);else if (onChange) onChange({
        target: {
          value: ""
        }
      });
    }
  }, /*#__PURE__*/React.createElement(XGlyph, null)) : null);
}
Object.assign(__ds_scope, { SearchInput });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/SearchInput.jsx", error: String((e && e.message) || e) }); }

// components/core/Select.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const CSS = `
.ds-select-field { display: flex; flex-direction: column; gap: var(--space-1-5); }
.ds-select-field__label {
  font-family: var(--font-mono);
  font-size: var(--text-2xs);
  font-weight: var(--weight-medium);
  letter-spacing: var(--tracking-wider);
  text-transform: uppercase;
  color: var(--text-tertiary);
}
.ds-select-wrap { position: relative; display: flex; align-items: center; }
.ds-select {
  width: 100%;
  height: var(--control-height-md);
  padding: 0 var(--space-9, 38px) 0 var(--space-3);
  font-family: var(--font-sans);
  font-size: var(--text-sm);
  color: var(--text-primary);
  background: var(--surface-card);
  border: 1px solid var(--border-default);
  border-radius: var(--radius-control);
  cursor: pointer;
  appearance: none;
  transition: border-color .15s ease, box-shadow .15s ease;
}
.ds-select:hover:not(:disabled) { border-color: var(--ink-400); }
.ds-select:focus { outline: none; border-color: var(--ink-900); box-shadow: 0 0 0 1px var(--ink-900); }
.ds-select:disabled { background: var(--surface-sunken); color: var(--text-disabled); cursor: not-allowed; }
.ds-select--sm { height: var(--control-height-sm); font-size: var(--text-xs); }
.ds-select__chevron {
  position: absolute; right: var(--space-3); pointer-events: none;
  display: inline-flex; color: var(--text-tertiary);
}
.ds-select__chevron svg { width: 16px; height: 16px; }
`;
if (typeof document !== "undefined" && !document.getElementById("ds-style-select")) {
  const el = document.createElement("style");
  el.id = "ds-style-select";
  el.textContent = CSS;
  document.head.appendChild(el);
}
const Chevron = () => /*#__PURE__*/React.createElement("svg", {
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: "1.75",
  strokeLinecap: "round",
  strokeLinejoin: "round",
  "aria-hidden": "true"
}, /*#__PURE__*/React.createElement("path", {
  d: "m6 9 6 6 6-6"
}));
function Select({
  label,
  options = [],
  placeholder,
  size = "md",
  id,
  className = "",
  children,
  ...rest
}) {
  const reactId = React.useId();
  const selectId = id || reactId;
  const selectClasses = ["ds-select", size !== "md" ? `ds-select--${size}` : "", className].filter(Boolean).join(" ");
  const control = /*#__PURE__*/React.createElement("div", {
    className: "ds-select-wrap"
  }, /*#__PURE__*/React.createElement("select", _extends({
    id: selectId,
    className: selectClasses
  }, rest), placeholder ? /*#__PURE__*/React.createElement("option", {
    value: ""
  }, placeholder) : null, children ? children : options.map(o => {
    const opt = typeof o === "string" ? {
      value: o,
      label: o
    } : o;
    return /*#__PURE__*/React.createElement("option", {
      key: opt.value,
      value: opt.value
    }, opt.label);
  })), /*#__PURE__*/React.createElement("span", {
    className: "ds-select__chevron"
  }, /*#__PURE__*/React.createElement(Chevron, null)));
  if (!label) return control;
  return /*#__PURE__*/React.createElement("div", {
    className: "ds-select-field"
  }, /*#__PURE__*/React.createElement("label", {
    className: "ds-select-field__label",
    htmlFor: selectId
  }, label), control);
}
Object.assign(__ds_scope, { Select });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Select.jsx", error: String((e && e.message) || e) }); }

// components/core/Switch.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const CSS = `
.ds-switch { display: inline-flex; align-items: center; gap: var(--space-2-5, 10px); cursor: pointer; user-select: none; }
.ds-switch--disabled { cursor: not-allowed; opacity: .5; }
.ds-switch__native { position: absolute; opacity: 0; width: 0; height: 0; }
.ds-switch__track {
  position: relative;
  width: 36px; height: 20px; flex: none;
  border-radius: var(--radius-pill);
  background: var(--ink-300);
  transition: background-color .16s ease;
}
.ds-switch__thumb {
  position: absolute; top: 2px; left: 2px;
  width: 16px; height: 16px;
  border-radius: var(--radius-full);
  background: var(--ink-0);
  box-shadow: var(--shadow-sm);
  transition: transform .16s cubic-bezier(.4,.0,.2,1);
}
.ds-switch__native:checked + .ds-switch__track { background: var(--action-primary); }
.ds-switch__native:checked + .ds-switch__track .ds-switch__thumb { transform: translateX(16px); }
.ds-switch:hover .ds-switch__native:not(:checked):not(:disabled) + .ds-switch__track { background: var(--ink-400); }
.ds-switch__native:focus-visible + .ds-switch__track { outline: 2px solid var(--focus-ring); outline-offset: 2px; }
.ds-switch__label { font-size: var(--text-sm); color: var(--text-primary); }
`;
if (typeof document !== "undefined" && !document.getElementById("ds-style-switch")) {
  const el = document.createElement("style");
  el.id = "ds-style-switch";
  el.textContent = CSS;
  document.head.appendChild(el);
}
function Switch({
  label,
  checked,
  defaultChecked,
  onChange,
  disabled = false,
  id,
  className = "",
  ...rest
}) {
  const reactId = React.useId();
  const swId = id || reactId;
  const classes = ["ds-switch", disabled ? "ds-switch--disabled" : "", className].filter(Boolean).join(" ");
  return /*#__PURE__*/React.createElement("label", {
    className: classes,
    htmlFor: swId
  }, /*#__PURE__*/React.createElement("input", _extends({
    id: swId,
    type: "checkbox",
    role: "switch",
    className: "ds-switch__native",
    checked: checked,
    defaultChecked: defaultChecked,
    onChange: onChange,
    disabled: disabled
  }, rest)), /*#__PURE__*/React.createElement("span", {
    className: "ds-switch__track"
  }, /*#__PURE__*/React.createElement("span", {
    className: "ds-switch__thumb"
  })), label ? /*#__PURE__*/React.createElement("span", {
    className: "ds-switch__label"
  }, label) : null);
}
Object.assign(__ds_scope, { Switch });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Switch.jsx", error: String((e && e.message) || e) }); }

// components/data-display/Badge.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const CSS = `
.ds-badge {
  display: inline-flex;
  align-items: center;
  gap: var(--space-1-5);
  height: 22px;
  padding: 0 var(--space-2-5, 10px);
  font-family: var(--font-mono);
  font-size: var(--text-2xs);
  font-weight: var(--weight-medium);
  letter-spacing: var(--tracking-wide);
  text-transform: uppercase;
  border-radius: var(--radius-badge);
  border: 1px solid transparent;
  white-space: nowrap;
}
.ds-badge--neutral { background: var(--surface-sunken); color: var(--text-secondary); border-color: var(--border-subtle); }
.ds-badge--outline { background: transparent; color: var(--text-secondary); border-color: var(--border-default); }
.ds-badge--solid { background: var(--action-primary); color: var(--action-on-primary); }
.ds-badge--legendary { background: var(--legendary-bg); color: var(--legendary); }
.ds-badge--danger { background: var(--danger-bg); color: var(--danger); }
.ds-badge--success { background: var(--success-bg); color: var(--success); }
.ds-badge--lg { height: 26px; font-size: var(--text-xs); padding: 0 var(--space-3); }
.ds-badge__dot { width: 6px; height: 6px; border-radius: 50%; background: currentColor; flex: none; }
`;
if (typeof document !== "undefined" && !document.getElementById("ds-style-badge")) {
  const el = document.createElement("style");
  el.id = "ds-style-badge";
  el.textContent = CSS;
  document.head.appendChild(el);
}
function Badge({
  variant = "neutral",
  size = "md",
  dot = false,
  className = "",
  children,
  ...rest
}) {
  const classes = ["ds-badge", `ds-badge--${variant}`, size === "lg" ? "ds-badge--lg" : "", className].filter(Boolean).join(" ");
  return /*#__PURE__*/React.createElement("span", _extends({
    className: classes
  }, rest), dot ? /*#__PURE__*/React.createElement("span", {
    className: "ds-badge__dot"
  }) : null, children);
}
Object.assign(__ds_scope, { Badge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data-display/Badge.jsx", error: String((e && e.message) || e) }); }

// components/data-display/Card.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const CSS = `
.ds-card {
  display: block;
  background: var(--surface-card);
  border: 1px solid var(--border-subtle);
  border-radius: var(--radius-card);
  box-shadow: var(--shadow-card);
  overflow: hidden;
}
.ds-card--pad { padding: var(--space-5); }
.ds-card--interactive {
  cursor: pointer;
  text-decoration: none;
  color: inherit;
  transition: border-color .16s ease, box-shadow .16s ease, transform .16s ease;
}
.ds-card--interactive:hover {
  border-color: var(--border-strong);
  box-shadow: var(--shadow-card-hover);
  transform: translateY(-2px);
}
.ds-card--interactive:active { transform: translateY(0); }
.ds-card--interactive:focus-visible { outline: 2px solid var(--focus-ring); outline-offset: 2px; }
`;
if (typeof document !== "undefined" && !document.getElementById("ds-style-card")) {
  const el = document.createElement("style");
  el.id = "ds-style-card";
  el.textContent = CSS;
  document.head.appendChild(el);
}
function Card({
  interactive = false,
  padded = false,
  as,
  href,
  className = "",
  children,
  ...rest
}) {
  const Tag = as || (href ? "a" : "div");
  const classes = ["ds-card", padded ? "ds-card--pad" : "", interactive || href ? "ds-card--interactive" : "", className].filter(Boolean).join(" ");
  return /*#__PURE__*/React.createElement(Tag, _extends({
    className: classes,
    href: href
  }, rest), children);
}
Object.assign(__ds_scope, { Card });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data-display/Card.jsx", error: String((e && e.message) || e) }); }

// components/data-display/StatBar.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const CSS = `
.ds-stat { display: grid; grid-template-columns: 92px 40px 1fr; align-items: center; gap: var(--space-3); }
.ds-stat__label {
  font-family: var(--font-mono);
  font-size: var(--text-2xs);
  font-weight: var(--weight-medium);
  letter-spacing: var(--tracking-wide);
  text-transform: uppercase;
  color: var(--text-tertiary);
}
.ds-stat__value {
  font-family: var(--font-mono);
  font-size: var(--text-sm);
  font-weight: var(--weight-medium);
  font-variant-numeric: tabular-nums;
  color: var(--text-primary);
  text-align: right;
}
.ds-stat__track {
  position: relative;
  height: 8px;
  background: var(--surface-sunken);
  border-radius: var(--radius-pill);
  overflow: hidden;
}
.ds-stat__fill {
  position: absolute; inset: 0 auto 0 0;
  height: 100%;
  background: var(--ink-900);
  border-radius: var(--radius-pill);
  transition: width .5s cubic-bezier(.4,0,.2,1);
}
.ds-stat--low .ds-stat__fill { background: var(--ink-400); }
.ds-stat--mid .ds-stat__fill { background: var(--ink-600); }
.ds-stat--high .ds-stat__fill { background: var(--ink-900); }
`;
if (typeof document !== "undefined" && !document.getElementById("ds-style-stat")) {
  const el = document.createElement("style");
  el.id = "ds-style-stat";
  el.textContent = CSS;
  document.head.appendChild(el);
}
function StatBar({
  label,
  value = 0,
  max = 255,
  className = "",
  ...rest
}) {
  const pct = Math.max(0, Math.min(100, value / max * 100));
  const tier = value >= 100 ? "high" : value >= 60 ? "mid" : "low";
  const classes = ["ds-stat", `ds-stat--${tier}`, className].filter(Boolean).join(" ");
  return /*#__PURE__*/React.createElement("div", _extends({
    className: classes
  }, rest), /*#__PURE__*/React.createElement("span", {
    className: "ds-stat__label"
  }, label), /*#__PURE__*/React.createElement("span", {
    className: "ds-stat__value"
  }, value), /*#__PURE__*/React.createElement("span", {
    className: "ds-stat__track",
    role: "meter",
    "aria-valuenow": value,
    "aria-valuemin": 0,
    "aria-valuemax": max,
    "aria-label": label
  }, /*#__PURE__*/React.createElement("span", {
    className: "ds-stat__fill",
    style: {
      width: `${pct}%`
    }
  })));
}
Object.assign(__ds_scope, { StatBar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data-display/StatBar.jsx", error: String((e && e.message) || e) }); }

// components/data-display/TypeBadge.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const POKEMON_TYPES = ["normal", "fire", "water", "electric", "grass", "ice", "fighting", "poison", "ground", "flying", "psychic", "bug", "rock", "ghost", "dragon", "dark", "steel", "fairy"];
const CSS = `
.ds-type {
  display: inline-flex;
  align-items: center;
  gap: var(--space-1-5);
  height: 22px;
  padding: 0 var(--space-2-5, 10px);
  font-family: var(--font-mono);
  font-size: var(--text-2xs);
  font-weight: var(--weight-medium);
  letter-spacing: var(--tracking-wide);
  text-transform: uppercase;
  border-radius: var(--radius-badge);
  border: 1px solid transparent;
  white-space: nowrap;
  background: var(--_bg);
  color: var(--_fg);
  cursor: default;
}
.ds-type--lg { height: 28px; font-size: var(--text-xs); padding: 0 var(--space-3); gap: var(--space-2); }
.ds-type__dot { width: 7px; height: 7px; border-radius: 50%; background: var(--_dot); flex: none; }
.ds-type--selectable { cursor: pointer; transition: filter .12s ease, box-shadow .12s ease; }
.ds-type--selectable:hover { filter: brightness(.97); }
.ds-type--selected { box-shadow: inset 0 0 0 1.5px var(--_dot); }
.ds-type[aria-pressed="false"] { background: var(--surface-card); color: var(--text-secondary); border-color: var(--border-default); }
.ds-type[aria-pressed="false"] .ds-type__dot { background: var(--_dot); }
.ds-type[aria-pressed="false"]:hover { border-color: var(--ink-400); filter: none; }
`;
if (typeof document !== "undefined" && !document.getElementById("ds-style-type")) {
  const el = document.createElement("style");
  el.id = "ds-style-type";
  el.textContent = CSS;
  document.head.appendChild(el);
}
function TypeBadge({
  type,
  size = "md",
  dot = true,
  selectable = false,
  selected,
  onClick,
  className = "",
  ...rest
}) {
  const t = String(type || "normal").toLowerCase();
  const style = {
    "--_bg": `var(--type-${t}-bg)`,
    "--_fg": `var(--type-${t}-text)`,
    "--_dot": `var(--type-${t})`
  };
  const classes = ["ds-type", size === "lg" ? "ds-type--lg" : "", selectable ? "ds-type--selectable" : "", selectable && selected ? "ds-type--selected" : "", className].filter(Boolean).join(" ");
  const content = /*#__PURE__*/React.createElement(React.Fragment, null, dot ? /*#__PURE__*/React.createElement("span", {
    className: "ds-type__dot"
  }) : null, t);
  if (selectable) {
    return /*#__PURE__*/React.createElement("button", _extends({
      type: "button",
      className: classes,
      style: style,
      "aria-pressed": !!selected,
      onClick: onClick
    }, rest), content);
  }
  return /*#__PURE__*/React.createElement("span", _extends({
    className: classes,
    style: style
  }, rest), content);
}
Object.assign(__ds_scope, { POKEMON_TYPES, TypeBadge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data-display/TypeBadge.jsx", error: String((e && e.message) || e) }); }

// components/data-display/PokemonCard.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Official artwork CDN URL for a given dex id (PokéAPI sprites repo). */
function artworkUrl(id) {
  return `https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/${id}.png`;
}
const CSS = `
.ds-pokecard { display: flex; flex-direction: column; }
.ds-pokecard__media {
  position: relative;
  aspect-ratio: 1 / 1;
  background:
    radial-gradient(120% 120% at 50% 18%, var(--surface-card) 0%, var(--surface-sunken) 100%);
  display: flex; align-items: center; justify-content: center;
  border-bottom: 1px solid var(--border-subtle);
}
.ds-pokecard__num {
  position: absolute; top: var(--space-3); left: var(--space-3);
  font-family: var(--font-mono);
  font-size: var(--text-xs);
  font-weight: var(--weight-medium);
  font-variant-numeric: tabular-nums;
  color: var(--text-tertiary);
  letter-spacing: var(--tracking-wide);
}
.ds-pokecard__img {
  width: 72%; height: 72%;
  object-fit: contain;
  image-rendering: auto;
  transition: transform .2s ease;
  filter: drop-shadow(0 6px 10px rgba(14,14,12,.12));
}
.ds-card--interactive:hover .ds-pokecard__img { transform: scale(1.05); }
.ds-pokecard__body { padding: var(--space-3) var(--space-4) var(--space-4); display: flex; flex-direction: column; gap: var(--space-2); }
.ds-pokecard__name {
  font-family: var(--font-sans);
  font-size: var(--text-lg);
  font-weight: var(--weight-bold);
  letter-spacing: var(--tracking-tight);
  color: var(--text-primary);
  line-height: var(--leading-tight);
  text-transform: capitalize;
}
.ds-pokecard__types { display: flex; flex-wrap: wrap; gap: var(--space-1-5); }
`;
if (typeof document !== "undefined" && !document.getElementById("ds-style-pokecard")) {
  const el = document.createElement("style");
  el.id = "ds-style-pokecard";
  el.textContent = CSS;
  document.head.appendChild(el);
}
function PokemonCard({
  id,
  name,
  types = [],
  image,
  href,
  onClick,
  className = "",
  ...rest
}) {
  const dex = id != null ? `#${String(id).padStart(4, "0")}` : null;
  const src = image || (id != null ? artworkUrl(id) : null);
  return /*#__PURE__*/React.createElement(__ds_scope.Card, _extends({
    interactive: true,
    href: href,
    onClick: onClick,
    className: ["ds-pokecard", className].filter(Boolean).join(" ")
  }, rest), /*#__PURE__*/React.createElement("div", {
    className: "ds-pokecard__media"
  }, dex ? /*#__PURE__*/React.createElement("span", {
    className: "ds-pokecard__num"
  }, dex) : null, src ? /*#__PURE__*/React.createElement("img", {
    className: "ds-pokecard__img",
    src: src,
    alt: name || "Pokémon",
    loading: "lazy"
  }) : null), /*#__PURE__*/React.createElement("div", {
    className: "ds-pokecard__body"
  }, /*#__PURE__*/React.createElement("div", {
    className: "ds-pokecard__name"
  }, name), /*#__PURE__*/React.createElement("div", {
    className: "ds-pokecard__types"
  }, types.map(t => /*#__PURE__*/React.createElement(__ds_scope.TypeBadge, {
    key: t,
    type: t
  })))));
}
Object.assign(__ds_scope, { artworkUrl, PokemonCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data-display/PokemonCard.jsx", error: String((e && e.message) || e) }); }

// components/feedback/EmptyState.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const CSS = `
.ds-empty {
  display: flex; flex-direction: column; align-items: center; text-align: center;
  gap: var(--space-3);
  padding: var(--space-16) var(--space-6);
  max-width: 420px; margin: 0 auto;
}
.ds-empty__icon {
  display: inline-flex; align-items: center; justify-content: center;
  width: 56px; height: 56px;
  border-radius: var(--radius-full);
  background: var(--surface-sunken);
  color: var(--text-tertiary);
  margin-bottom: var(--space-1);
}
.ds-empty__icon svg { width: 26px; height: 26px; }
.ds-empty__title {
  font-family: var(--font-sans);
  font-size: var(--text-lg);
  font-weight: var(--weight-bold);
  letter-spacing: var(--tracking-tight);
  color: var(--text-primary);
}
.ds-empty__desc { font-size: var(--text-sm); color: var(--text-secondary); line-height: var(--leading-normal); }
.ds-empty__actions { margin-top: var(--space-2); display: flex; gap: var(--space-2); }
`;
if (typeof document !== "undefined" && !document.getElementById("ds-style-empty")) {
  const el = document.createElement("style");
  el.id = "ds-style-empty";
  el.textContent = CSS;
  document.head.appendChild(el);
}
const DefaultGlyph = () => /*#__PURE__*/React.createElement("svg", {
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: "1.6",
  strokeLinecap: "round",
  strokeLinejoin: "round",
  "aria-hidden": "true"
}, /*#__PURE__*/React.createElement("circle", {
  cx: "11",
  cy: "11",
  r: "7"
}), /*#__PURE__*/React.createElement("path", {
  d: "m21 21-4.3-4.3"
}));
function EmptyState({
  icon,
  title = "No Pokémon found",
  description,
  action,
  className = "",
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    className: ["ds-empty", className].filter(Boolean).join(" ")
  }, rest), /*#__PURE__*/React.createElement("span", {
    className: "ds-empty__icon"
  }, icon || /*#__PURE__*/React.createElement(DefaultGlyph, null)), /*#__PURE__*/React.createElement("div", {
    className: "ds-empty__title"
  }, title), description ? /*#__PURE__*/React.createElement("div", {
    className: "ds-empty__desc"
  }, description) : null, action ? /*#__PURE__*/React.createElement("div", {
    className: "ds-empty__actions"
  }, action) : null);
}
Object.assign(__ds_scope, { EmptyState });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/EmptyState.jsx", error: String((e && e.message) || e) }); }

// components/navigation/Pagination.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const CSS = `
.ds-pager { display: inline-flex; align-items: center; gap: var(--space-1-5); }
.ds-pager__btn {
  min-width: 36px; height: 36px;
  display: inline-flex; align-items: center; justify-content: center;
  padding: 0 var(--space-2);
  font-family: var(--font-mono);
  font-size: var(--text-sm);
  font-variant-numeric: tabular-nums;
  color: var(--text-secondary);
  background: var(--surface-card);
  border: 1px solid var(--border-default);
  border-radius: var(--radius-control);
  cursor: pointer;
  transition: background-color .12s ease, border-color .12s ease, color .12s ease;
}
.ds-pager__btn:hover:not(:disabled):not([aria-current="page"]) { background: var(--surface-hover); border-color: var(--ink-400); color: var(--text-primary); }
.ds-pager__btn:disabled { opacity: .4; cursor: not-allowed; }
.ds-pager__btn[aria-current="page"] { background: var(--action-primary); border-color: var(--action-primary); color: var(--action-on-primary); cursor: default; }
.ds-pager__btn svg { width: 16px; height: 16px; }
.ds-pager__ellipsis { min-width: 24px; text-align: center; color: var(--text-tertiary); font-family: var(--font-mono); font-size: var(--text-sm); }
`;
if (typeof document !== "undefined" && !document.getElementById("ds-style-pager")) {
  const el = document.createElement("style");
  el.id = "ds-style-pager";
  el.textContent = CSS;
  document.head.appendChild(el);
}
const ChevL = () => /*#__PURE__*/React.createElement("svg", {
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: "1.75",
  strokeLinecap: "round",
  strokeLinejoin: "round"
}, /*#__PURE__*/React.createElement("path", {
  d: "m15 18-6-6 6-6"
}));
const ChevR = () => /*#__PURE__*/React.createElement("svg", {
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: "1.75",
  strokeLinecap: "round",
  strokeLinejoin: "round"
}, /*#__PURE__*/React.createElement("path", {
  d: "m9 18 6-6-6-6"
}));

/** Build a compact page-number model with ellipses. */
function pageModel(current, total, siblings = 1) {
  const out = [];
  const push = v => out.push(v);
  const left = Math.max(2, current - siblings);
  const right = Math.min(total - 1, current + siblings);
  push(1);
  if (left > 2) push("…");
  for (let p = left; p <= right; p++) push(p);
  if (right < total - 1) push("…");
  if (total > 1) push(total);
  return out;
}
function Pagination({
  page = 1,
  totalPages = 1,
  onPageChange,
  siblingCount = 1,
  className = "",
  ...rest
}) {
  const go = p => {
    if (onPageChange && p >= 1 && p <= totalPages && p !== page) onPageChange(p);
  };
  const model = pageModel(page, totalPages, siblingCount);
  return /*#__PURE__*/React.createElement("nav", _extends({
    className: ["ds-pager", className].filter(Boolean).join(" "),
    "aria-label": "Pagination"
  }, rest), /*#__PURE__*/React.createElement("button", {
    className: "ds-pager__btn",
    "aria-label": "Previous page",
    disabled: page <= 1,
    onClick: () => go(page - 1)
  }, /*#__PURE__*/React.createElement(ChevL, null)), model.map((p, i) => p === "…" ? /*#__PURE__*/React.createElement("span", {
    key: `e${i}`,
    className: "ds-pager__ellipsis"
  }, "\u2026") : /*#__PURE__*/React.createElement("button", {
    key: p,
    className: "ds-pager__btn",
    "aria-current": p === page ? "page" : undefined,
    onClick: () => go(p)
  }, p)), /*#__PURE__*/React.createElement("button", {
    className: "ds-pager__btn",
    "aria-label": "Next page",
    disabled: page >= totalPages,
    onClick: () => go(page + 1)
  }, /*#__PURE__*/React.createElement(ChevR, null)));
}
Object.assign(__ds_scope, { Pagination });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/Pagination.jsx", error: String((e && e.message) || e) }); }

// ui_kits/explorer/AppShell.jsx
try { (() => {
/* App shell — top bar with the wordmark + a footer crediting PokéAPI
   (BC-BRAND-02). Pure layout; screens render as children. */
(function () {
  const shellCSS = `
  .px-shell { min-height: 100%; display: flex; flex-direction: column; background: var(--color-bg); }
  .px-topbar {
    position: sticky; top: 0; z-index: 20;
    display: flex; align-items: center; justify-content: space-between;
    height: 60px; padding: 0 var(--space-6);
    background: color-mix(in oklab, var(--color-bg) 86%, transparent);
    backdrop-filter: saturate(140%) blur(8px);
    border-bottom: 1px solid var(--border-subtle);
  }
  .px-brand { display: inline-flex; align-items: baseline; gap: 8px; text-decoration: none; }
  .px-brand__name { font-family: var(--font-sans); font-weight: 800; font-size: 19px; letter-spacing: -0.03em; color: var(--ink-900); }
  .px-brand__tag { font-family: var(--font-mono); font-weight: 500; font-size: 10px; letter-spacing: .12em; text-transform: uppercase; color: var(--paper); background: var(--ink-900); padding: 2px 6px; border-radius: var(--radius-sm); }
  .px-topbar__meta { font-family: var(--font-mono); font-size: 11px; color: var(--text-tertiary); letter-spacing: .02em; }
  .px-main { flex: 1; width: 100%; max-width: var(--container-max); margin: 0 auto; padding: var(--space-8) var(--space-6) var(--space-12); }
  .px-footer {
    border-top: 1px solid var(--border-subtle);
    padding: var(--space-6);
    display: flex; justify-content: center;
  }
  .px-footer__inner { width: 100%; max-width: var(--container-max); display: flex; align-items: center; justify-content: space-between; font-size: var(--text-xs); color: var(--text-tertiary); }
  .px-footer a { color: var(--text-secondary); text-underline-offset: .2em; }
  @media (max-width: 768px) { .px-main { padding: var(--space-6) var(--space-4) var(--space-10); } .px-topbar { padding: 0 var(--space-4); } }
  `;
  if (!document.getElementById("px-shell-style")) {
    const el = document.createElement("style");
    el.id = "px-shell-style";
    el.textContent = shellCSS;
    document.head.appendChild(el);
  }
  function AppShell({
    onHome,
    children
  }) {
    return /*#__PURE__*/React.createElement("div", {
      className: "px-shell"
    }, /*#__PURE__*/React.createElement("header", {
      className: "px-topbar"
    }, /*#__PURE__*/React.createElement("a", {
      className: "px-brand",
      href: "#",
      onClick: e => {
        e.preventDefault();
        onHome && onHome();
      }
    }, /*#__PURE__*/React.createElement("span", {
      className: "px-brand__name"
    }, "Pok\xE9dex"), /*#__PURE__*/React.createElement("span", {
      className: "px-brand__tag"
    }, "EXPLORER")), /*#__PURE__*/React.createElement("span", {
      className: "px-topbar__meta"
    }, "1025 Pok\xE9mon \xB7 keyless \xB7 no trackers")), /*#__PURE__*/React.createElement("main", {
      className: "px-main"
    }, children), /*#__PURE__*/React.createElement("footer", {
      className: "px-footer"
    }, /*#__PURE__*/React.createElement("div", {
      className: "px-footer__inner"
    }, /*#__PURE__*/React.createElement("span", null, "Data from ", /*#__PURE__*/React.createElement("a", {
      href: "https://pokeapi.co",
      target: "_blank",
      rel: "noopener noreferrer"
    }, "Pok\xE9API")), /*#__PURE__*/React.createElement("span", null, "No accounts \xB7 no cookies \xB7 no analytics"))));
  }
  window.AppShell = AppShell;
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/explorer/AppShell.jsx", error: String((e && e.message) || e) }); }

// ui_kits/explorer/DetailScreen.jsx
try { (() => {
/* Detail screen — full profile for one Pokémon (FR-DETAIL-01..09):
   artwork, dex number, name, genus, types, flavor text, base stats,
   abilities (hidden marked), height/weight (metric), generation, and a
   Legendary/Mythical label when applicable. Back link returns to the list. */
(function () {
  const NS = window.PokDexExplorerDesignSystem_6555a0;
  const {
    TypeBadge,
    Badge,
    StatBar,
    artworkUrl
  } = NS;
  const {
    ArrowLeft,
    Ruler,
    Weight,
    Sparkles,
    Layers
  } = window.PokeIcons;
  const dsCSS = `
  .px-detail { display: flex; flex-direction: column; gap: var(--space-6); }
  .px-back { align-self: flex-start; display: inline-flex; align-items: center; gap: var(--space-2); padding: var(--space-2) var(--space-3) var(--space-2) var(--space-2); border-radius: var(--radius-control); border: 1px solid transparent; background: transparent; color: var(--text-secondary); font-family: var(--font-sans); font-size: var(--text-sm); font-weight: 600; cursor: pointer; transition: background-color .12s, color .12s; }
  .px-back:hover { background: var(--surface-hover); color: var(--text-primary); }
  .px-detail__grid { display: grid; grid-template-columns: 440px 1fr; gap: var(--space-8); align-items: start; }
  .px-art {
    position: sticky; top: 84px;
    aspect-ratio: 1 / 1;
    background: radial-gradient(120% 120% at 50% 22%, var(--surface-card) 0%, var(--surface-sunken) 100%);
    border: 1px solid var(--border-subtle); border-radius: var(--radius-2xl);
    display: flex; align-items: center; justify-content: center; overflow: hidden;
  }
  .px-art__num { position: absolute; top: var(--space-5); left: var(--space-5); font-family: var(--font-mono); font-size: var(--text-md); color: var(--text-tertiary); font-variant-numeric: tabular-nums; letter-spacing: .02em; }
  .px-art img { width: 76%; height: 76%; object-fit: contain; filter: drop-shadow(0 14px 22px rgba(14,14,12,.16)); }
  .px-info { display: flex; flex-direction: column; gap: var(--space-6); }
  .px-info__genus { font-family: var(--font-mono); font-size: var(--text-xs); letter-spacing: .08em; text-transform: uppercase; color: var(--text-tertiary); }
  .px-info__name { font-family: var(--font-sans); font-weight: 800; font-size: var(--text-5xl); letter-spacing: -0.03em; line-height: 1; color: var(--text-primary); text-transform: capitalize; margin-top: 4px; }
  .px-info__types { display: flex; gap: var(--space-2); margin-top: var(--space-3); }
  .px-flavor { font-size: var(--text-md); line-height: 1.6; color: var(--text-secondary); max-width: 56ch; }
  .px-section { display: flex; flex-direction: column; gap: var(--space-3); }
  .px-section__title { font-family: var(--font-mono); font-size: var(--text-2xs); font-weight: 500; letter-spacing: .08em; text-transform: uppercase; color: var(--text-tertiary); }
  .px-stats { display: flex; flex-direction: column; gap: var(--space-2-5, 10px); }
  .px-meta { display: grid; grid-template-columns: repeat(3, 1fr); gap: var(--space-3); }
  .px-meta__item { border: 1px solid var(--border-subtle); border-radius: var(--radius-lg); padding: var(--space-4); display: flex; flex-direction: column; gap: var(--space-2); background: var(--surface-card); }
  .px-meta__k { display: inline-flex; align-items: center; gap: 6px; font-family: var(--font-mono); font-size: var(--text-2xs); letter-spacing: .06em; text-transform: uppercase; color: var(--text-tertiary); }
  .px-meta__v { font-family: var(--font-mono); font-size: var(--text-lg); font-weight: 500; color: var(--text-primary); font-variant-numeric: tabular-nums; }
  .px-abilities { display: flex; flex-wrap: wrap; gap: var(--space-2); }
  .px-ability { display: inline-flex; align-items: center; gap: 8px; padding: 8px 14px; border: 1px solid var(--border-default); border-radius: var(--radius-pill); background: var(--surface-card); font-size: var(--text-sm); color: var(--text-primary); text-transform: capitalize; }
  .px-ability__hidden { font-family: var(--font-mono); font-size: 9.5px; letter-spacing: .06em; text-transform: uppercase; color: var(--text-tertiary); border: 1px solid var(--border-default); border-radius: var(--radius-sm); padding: 1px 5px; }
  @media (max-width: 1024px) { .px-detail__grid { grid-template-columns: 1fr; } .px-art { position: static; max-width: 380px; } .px-info__name { font-size: var(--text-4xl); } }
  `;
  if (!document.getElementById("px-detail-style")) {
    const el = document.createElement("style");
    el.id = "px-detail-style";
    el.textContent = dsCSS;
    document.head.appendChild(el);
  }
  const STAT_ROWS = [["hp", "HP"], ["atk", "Attack"], ["def", "Defense"], ["spa", "Sp. Atk"], ["spd", "Sp. Def"], ["spe", "Speed"]];
  const GEN_LABEL = {
    1: "Gen 1 — Kanto",
    2: "Gen 2 — Johto",
    3: "Gen 3 — Hoenn",
    4: "Gen 4 — Sinnoh",
    5: "Gen 5 — Unova",
    6: "Gen 6 — Kalos",
    7: "Gen 7 — Alola",
    8: "Gen 8 — Galar",
    9: "Gen 9 — Paldea"
  };
  function DetailScreen({
    pokemon: p,
    onBack
  }) {
    const dex = `#${String(p.id).padStart(4, "0")}`;
    return /*#__PURE__*/React.createElement("div", {
      className: "px-detail"
    }, /*#__PURE__*/React.createElement("button", {
      className: "px-back",
      onClick: onBack
    }, /*#__PURE__*/React.createElement(ArrowLeft, {
      size: 18
    }), " Back to results"), /*#__PURE__*/React.createElement("div", {
      className: "px-detail__grid"
    }, /*#__PURE__*/React.createElement("div", {
      className: "px-art"
    }, /*#__PURE__*/React.createElement("span", {
      className: "px-art__num"
    }, dex), /*#__PURE__*/React.createElement("img", {
      src: artworkUrl(p.id),
      alt: p.name
    })), /*#__PURE__*/React.createElement("div", {
      className: "px-info"
    }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
      className: "px-info__genus"
    }, p.genus), /*#__PURE__*/React.createElement("h1", {
      className: "px-info__name"
    }, p.name), /*#__PURE__*/React.createElement("div", {
      className: "px-info__types"
    }, p.types.map(t => /*#__PURE__*/React.createElement(TypeBadge, {
      key: t,
      type: t,
      size: "lg"
    })), p.legendary ? /*#__PURE__*/React.createElement(Badge, {
      variant: "legendary",
      size: "lg"
    }, "Legendary") : null, p.mythical ? /*#__PURE__*/React.createElement(Badge, {
      variant: "legendary",
      size: "lg"
    }, "Mythical") : null)), /*#__PURE__*/React.createElement("p", {
      className: "px-flavor"
    }, p.flavor), /*#__PURE__*/React.createElement("div", {
      className: "px-section"
    }, /*#__PURE__*/React.createElement("div", {
      className: "px-section__title"
    }, "Base stats"), /*#__PURE__*/React.createElement("div", {
      className: "px-stats"
    }, STAT_ROWS.map(([k, label]) => /*#__PURE__*/React.createElement(StatBar, {
      key: k,
      label: label,
      value: p.stats[k]
    })))), /*#__PURE__*/React.createElement("div", {
      className: "px-section"
    }, /*#__PURE__*/React.createElement("div", {
      className: "px-section__title"
    }, "Profile"), /*#__PURE__*/React.createElement("div", {
      className: "px-meta"
    }, /*#__PURE__*/React.createElement("div", {
      className: "px-meta__item"
    }, /*#__PURE__*/React.createElement("span", {
      className: "px-meta__k"
    }, /*#__PURE__*/React.createElement(Ruler, {
      size: 13
    }), " Height"), /*#__PURE__*/React.createElement("span", {
      className: "px-meta__v"
    }, p.height.toFixed(1), " m")), /*#__PURE__*/React.createElement("div", {
      className: "px-meta__item"
    }, /*#__PURE__*/React.createElement("span", {
      className: "px-meta__k"
    }, /*#__PURE__*/React.createElement(Weight, {
      size: 13
    }), " Weight"), /*#__PURE__*/React.createElement("span", {
      className: "px-meta__v"
    }, p.weight.toFixed(1), " kg")), /*#__PURE__*/React.createElement("div", {
      className: "px-meta__item"
    }, /*#__PURE__*/React.createElement("span", {
      className: "px-meta__k"
    }, /*#__PURE__*/React.createElement(Layers, {
      size: 13
    }), " Generation"), /*#__PURE__*/React.createElement("span", {
      className: "px-meta__v",
      style: {
        fontSize: "var(--text-sm)"
      }
    }, GEN_LABEL[p.generation])))), /*#__PURE__*/React.createElement("div", {
      className: "px-section"
    }, /*#__PURE__*/React.createElement("div", {
      className: "px-section__title"
    }, "Abilities"), /*#__PURE__*/React.createElement("div", {
      className: "px-abilities"
    }, p.abilities.map(a => /*#__PURE__*/React.createElement("span", {
      key: a.name,
      className: "px-ability"
    }, a.name, a.hidden ? /*#__PURE__*/React.createElement("span", {
      className: "px-ability__hidden"
    }, "Hidden") : null)))))));
  }
  window.DetailScreen = DetailScreen;
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/explorer/DetailScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/explorer/FilterBar.jsx
try { (() => {
/* Filter bar — name search, type multi-select chips, generation select,
   legendary switch, and clear (FR-SEARCH-01, FR-FILTER-01..05). Controlled. */
(function () {
  const NS = window.PokDexExplorerDesignSystem_6555a0;
  const {
    SearchInput,
    Select,
    Switch,
    TypeBadge,
    POKEMON_TYPES,
    Button
  } = NS;
  const fbCSS = `
  .px-filters { display: flex; flex-direction: column; gap: var(--space-4); }
  .px-filters__top { display: grid; grid-template-columns: minmax(0,1fr) 220px; gap: var(--space-3); align-items: end; }
  .px-filters__chips { display: flex; flex-wrap: wrap; gap: var(--space-1-5); }
  .px-filters__bottom { display: flex; align-items: center; justify-content: space-between; gap: var(--space-4); flex-wrap: wrap; }
  .px-filters__legend { display: flex; align-items: center; gap: var(--space-4); }
  .px-fieldlabel { font-family: var(--font-mono); font-size: 11px; font-weight: 500; letter-spacing: .08em; text-transform: uppercase; color: var(--text-tertiary); margin-bottom: var(--space-2); }
  @media (max-width: 768px) { .px-filters__top { grid-template-columns: 1fr; } }
  `;
  if (!document.getElementById("px-filters-style")) {
    const el = document.createElement("style");
    el.id = "px-filters-style";
    el.textContent = fbCSS;
    document.head.appendChild(el);
  }
  function FilterBar({
    filters,
    setFilters,
    generations,
    resultCount,
    totalCount
  }) {
    const {
      search,
      types,
      generation,
      legendary
    } = filters;
    const activeCount = types.length + (generation ? 1 : 0) + (legendary ? 1 : 0) + (search ? 1 : 0);
    const toggleType = t => {
      const next = types.includes(t) ? types.filter(x => x !== t) : [...types, t];
      setFilters({
        ...filters,
        types: next
      });
    };
    return /*#__PURE__*/React.createElement("div", {
      className: "px-filters"
    }, /*#__PURE__*/React.createElement("div", {
      className: "px-filters__top"
    }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
      className: "px-fieldlabel"
    }, "Search"), /*#__PURE__*/React.createElement(SearchInput, {
      value: search,
      onChange: e => setFilters({
        ...filters,
        search: e.target.value
      })
    })), /*#__PURE__*/React.createElement(Select, {
      label: "Generation",
      placeholder: "All generations",
      options: generations,
      value: generation,
      onChange: e => setFilters({
        ...filters,
        generation: e.target.value
      })
    })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
      className: "px-fieldlabel"
    }, "Types"), /*#__PURE__*/React.createElement("div", {
      className: "px-filters__chips"
    }, POKEMON_TYPES.map(t => /*#__PURE__*/React.createElement(TypeBadge, {
      key: t,
      type: t,
      selectable: true,
      selected: types.includes(t),
      onClick: () => toggleType(t)
    })))), /*#__PURE__*/React.createElement("div", {
      className: "px-filters__bottom"
    }, /*#__PURE__*/React.createElement("div", {
      className: "px-filters__legend"
    }, /*#__PURE__*/React.createElement(Switch, {
      label: "Legendary & Mythical only",
      checked: legendary,
      onChange: e => setFilters({
        ...filters,
        legendary: e.target.checked
      })
    }), /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: "var(--font-mono)",
        fontSize: 12,
        color: "var(--text-tertiary)"
      }
    }, resultCount, " of ", totalCount)), activeCount > 0 ? /*#__PURE__*/React.createElement(Button, {
      variant: "ghost",
      size: "sm",
      onClick: () => setFilters({
        search: "",
        types: [],
        generation: "",
        legendary: false
      })
    }, "Clear filters (", activeCount, ")") : null));
  }
  window.FilterBar = FilterBar;
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/explorer/FilterBar.jsx", error: String((e && e.message) || e) }); }

// ui_kits/explorer/ListScreen.jsx
try { (() => {
/* List screen — filter bar, responsive results grid, pagination, empty state
   (FR-LIST-01..04, FR-PAGE-01..02). Filtering/pagination computed locally. */
(function () {
  const NS = window.PokDexExplorerDesignSystem_6555a0;
  const {
    PokemonCard,
    Pagination,
    EmptyState,
    Button
  } = NS;
  const lsCSS = `
  .px-list { display: flex; flex-direction: column; gap: var(--space-8); }
  .px-list__head { display: flex; flex-direction: column; gap: var(--space-2); }
  .px-list__title { font-family: var(--font-sans); font-weight: 800; font-size: var(--text-3xl); letter-spacing: -0.03em; color: var(--text-primary); line-height: 1.05; }
  .px-list__sub { font-size: var(--text-base); color: var(--text-secondary); max-width: 52ch; }
  .px-list__panel { background: var(--surface-card); border: 1px solid var(--border-subtle); border-radius: var(--radius-xl); padding: var(--space-6); }
  .px-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: var(--space-5); }
  .px-list__footer { display: flex; justify-content: center; padding-top: var(--space-2); }
  @media (max-width: 1280px) { .px-grid { grid-template-columns: repeat(3, 1fr); } }
  @media (max-width: 768px) { .px-grid { grid-template-columns: 1fr; } .px-list__title { font-size: var(--text-2xl); } }
  @media (min-width: 769px) and (max-width: 1024px) { .px-grid { grid-template-columns: repeat(2, 1fr); } }
  `;
  if (!document.getElementById("px-list-style")) {
    const el = document.createElement("style");
    el.id = "px-list-style";
    el.textContent = lsCSS;
    document.head.appendChild(el);
  }
  function matches(p, f) {
    if (f.search && !p.name.toLowerCase().includes(f.search.trim().toLowerCase())) return false;
    if (f.types.length && !p.types.some(t => f.types.includes(t))) return false;
    if (f.generation && String(p.generation) !== String(f.generation)) return false;
    if (f.legendary && !(p.legendary || p.mythical)) return false;
    return true;
  }
  function ListScreen({
    data,
    filters,
    setFilters,
    page,
    setPage,
    onSelect
  }) {
    const {
      FilterBar
    } = window;
    const filtered = data.pokemon.filter(p => matches(p, filters));
    const pageSize = data.pageSize;
    const totalPages = Math.max(1, Math.ceil(filtered.length / pageSize));
    const safePage = Math.min(page, totalPages);
    const start = (safePage - 1) * pageSize;
    const pageItems = filtered.slice(start, start + pageSize);
    return /*#__PURE__*/React.createElement("div", {
      className: "px-list"
    }, /*#__PURE__*/React.createElement("div", {
      className: "px-list__head"
    }, /*#__PURE__*/React.createElement("h1", {
      className: "px-list__title"
    }, "Search the dex"), /*#__PURE__*/React.createElement("p", {
      className: "px-list__sub"
    }, "Browse every Pok\xE9mon. Filter by type, generation, or legendary status, then open a card for the full profile.")), /*#__PURE__*/React.createElement(FilterBar, {
      filters: filters,
      setFilters: f => {
        setFilters(f);
        setPage(1);
      },
      generations: data.generations,
      resultCount: filtered.length,
      totalCount: data.pokemon.length
    }), pageItems.length === 0 ? /*#__PURE__*/React.createElement(EmptyState, {
      title: "No Pok\xE9mon found",
      description: "Nothing matches your current search and filters. Try a different name or clear some filters.",
      action: /*#__PURE__*/React.createElement(Button, {
        variant: "secondary",
        onClick: () => setFilters({
          search: "",
          types: [],
          generation: "",
          legendary: false
        })
      }, "Clear filters")
    }) : /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
      className: "px-grid"
    }, pageItems.map(p => /*#__PURE__*/React.createElement(PokemonCard, {
      key: p.id,
      id: p.id,
      name: p.name,
      types: p.types,
      href: "#",
      onClick: e => {
        e.preventDefault();
        onSelect(p);
      }
    }))), totalPages > 1 ? /*#__PURE__*/React.createElement("div", {
      className: "px-list__footer"
    }, /*#__PURE__*/React.createElement(Pagination, {
      page: safePage,
      totalPages: totalPages,
      onPageChange: setPage
    })) : null));
  }
  window.ListScreen = ListScreen;
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/explorer/ListScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/explorer/data.js
try { (() => {
/* Pokédex Explorer — sample dataset for the UI kit.
   A curated slice of the National Dex with full detail, spanning types,
   generations, and legendary/mythical status. Artwork resolves to the
   public PokéAPI sprites CDN via id (see artworkUrl in PokemonCard). */
(function () {
  const P = (id, name, genus, types, stats, abilities, height, weight, generation, flavor, flags = {}) => ({
    id,
    name,
    genus,
    types,
    stats: {
      hp: stats[0],
      atk: stats[1],
      def: stats[2],
      spa: stats[3],
      spd: stats[4],
      spe: stats[5]
    },
    abilities,
    height,
    weight,
    generation,
    legendary: !!flags.legendary,
    mythical: !!flags.mythical,
    flavor
  });
  window.PokedexData = {
    pageSize: 12,
    // NOTE: production spec is 20/page (FR-LIST-01); 12 reads better in the kit grid.
    generations: [{
      value: "1",
      label: "Gen 1 — Kanto"
    }, {
      value: "2",
      label: "Gen 2 — Johto"
    }, {
      value: "3",
      label: "Gen 3 — Hoenn"
    }, {
      value: "4",
      label: "Gen 4 — Sinnoh"
    }, {
      value: "5",
      label: "Gen 5 — Unova"
    }, {
      value: "6",
      label: "Gen 6 — Kalos"
    }, {
      value: "7",
      label: "Gen 7 — Alola"
    }, {
      value: "8",
      label: "Gen 8 — Galar"
    }, {
      value: "9",
      label: "Gen 9 — Paldea"
    }],
    pokemon: [P(1, "Bulbasaur", "Seed Pokémon", ["grass", "poison"], [45, 49, 49, 65, 65, 45], [{
      name: "Overgrow"
    }, {
      name: "Chlorophyll",
      hidden: true
    }], 0.7, 6.9, 1, "A strange seed was planted on its back at birth. The plant sprouts and grows with this Pokémon."), P(4, "Charmander", "Lizard Pokémon", ["fire"], [39, 52, 43, 60, 50, 65], [{
      name: "Blaze"
    }, {
      name: "Solar Power",
      hidden: true
    }], 0.6, 8.5, 1, "Obviously prefers hot places. When it rains, steam is said to spout from the tip of its tail."), P(6, "Charizard", "Flame Pokémon", ["fire", "flying"], [78, 84, 78, 109, 85, 100], [{
      name: "Blaze"
    }, {
      name: "Solar Power",
      hidden: true
    }], 1.7, 90.5, 1, "Spits fire that is hot enough to melt boulders. May cause forest fires by blowing flames."), P(7, "Squirtle", "Tiny Turtle Pokémon", ["water"], [44, 48, 65, 50, 64, 43], [{
      name: "Torrent"
    }, {
      name: "Rain Dish",
      hidden: true
    }], 0.5, 9.0, 1, "After birth, its back swells and hardens into a shell. Powerfully sprays foam from its mouth."), P(25, "Pikachu", "Mouse Pokémon", ["electric"], [35, 55, 40, 50, 50, 90], [{
      name: "Static"
    }, {
      name: "Lightning Rod",
      hidden: true
    }], 0.4, 6.0, 1, "When several of these Pokémon gather, their electricity could build and cause lightning storms."), P(94, "Gengar", "Shadow Pokémon", ["ghost", "poison"], [60, 65, 60, 130, 75, 110], [{
      name: "Cursed Body"
    }], 1.5, 40.5, 1, "Under a full moon, this Pokémon likes to mimic the shadows of people and laugh at their fright."), P(130, "Gyarados", "Atrocious Pokémon", ["water", "flying"], [95, 125, 79, 60, 100, 81], [{
      name: "Intimidate"
    }, {
      name: "Moxie",
      hidden: true
    }], 6.5, 235.0, 1, "Rarely seen in the wild. Huge and vicious, it is capable of destroying entire cities in a rage."), P(143, "Snorlax", "Sleeping Pokémon", ["normal"], [160, 110, 65, 65, 110, 30], [{
      name: "Immunity"
    }, {
      name: "Gluttony",
      hidden: true
    }], 2.1, 460.0, 1, "Very lazy. Just eats and sleeps. As its rotund bulk builds, it becomes steadily more slothful."), P(149, "Dragonite", "Dragon Pokémon", ["dragon", "flying"], [91, 134, 95, 100, 100, 80], [{
      name: "Inner Focus"
    }, {
      name: "Multiscale",
      hidden: true
    }], 2.2, 210.0, 1, "An extremely rarely seen marine Pokémon. Its intelligence is said to match that of humans."), P(150, "Mewtwo", "Genetic Pokémon", ["psychic"], [106, 110, 90, 154, 90, 130], [{
      name: "Pressure"
    }, {
      name: "Unnerve",
      hidden: true
    }], 2.0, 122.0, 1, "Created by a scientist after years of horrific gene-splicing and DNA-engineering experiments.", {
      legendary: true
    }), P(151, "Mew", "New Species Pokémon", ["psychic"], [100, 100, 100, 100, 100, 100], [{
      name: "Synchronize"
    }], 0.4, 4.0, 1, "So rare it is still said to be a mirage by many experts. Only a few people have seen it worldwide.", {
      mythical: true
    }), P(196, "Espeon", "Sun Pokémon", ["psychic"], [65, 65, 60, 130, 95, 110], [{
      name: "Synchronize"
    }, {
      name: "Magic Bounce",
      hidden: true
    }], 0.9, 26.5, 2, "It uses the fine hair covering its body to sense air currents and predict its enemy's actions."), P(248, "Tyranitar", "Armor Pokémon", ["rock", "dark"], [100, 134, 110, 95, 100, 61], [{
      name: "Sand Stream"
    }, {
      name: "Unnerve",
      hidden: true
    }], 2.0, 202.0, 2, "Its body can't be harmed by any sort of attack, so it is very eager to make challenges."), P(257, "Blaziken", "Blaze Pokémon", ["fire", "fighting"], [80, 120, 70, 110, 70, 80], [{
      name: "Blaze"
    }, {
      name: "Speed Boost",
      hidden: true
    }], 1.9, 52.0, 3, "Learns powerful kicks. Can leap over a building in one bound. Its blazing punches leave scorch marks."), P(282, "Gardevoir", "Embrace Pokémon", ["psychic", "fairy"], [68, 65, 65, 125, 115, 80], [{
      name: "Synchronize"
    }, {
      name: "Trace"
    }, {
      name: "Telepathy",
      hidden: true
    }], 1.6, 48.4, 3, "To protect its Trainer, it will expend all its psychic power to create a small black hole."), P(384, "Rayquaza", "Sky High Pokémon", ["dragon", "flying"], [105, 150, 90, 150, 90, 95], [{
      name: "Air Lock"
    }], 7.0, 206.5, 3, "It flies forever through the ozone layer, consuming meteoroids for sustenance.", {
      legendary: true
    }), P(448, "Lucario", "Aura Pokémon", ["fighting", "steel"], [70, 110, 70, 115, 70, 90], [{
      name: "Steadfast"
    }, {
      name: "Inner Focus"
    }, {
      name: "Justified",
      hidden: true
    }], 1.2, 54.0, 4, "By catching the aura emanating from others, it can read their thoughts and movements."), P(445, "Garchomp", "Mach Pokémon", ["dragon", "ground"], [108, 130, 95, 80, 85, 102], [{
      name: "Sand Veil"
    }, {
      name: "Rough Skin",
      hidden: true
    }], 1.9, 95.0, 4, "When it folds up its body and extends its wings, it looks like a jet plane and flies at sonic speed."), P(491, "Darkrai", "Pitch-Black Pokémon", ["dark"], [70, 90, 90, 135, 90, 125], [{
      name: "Bad Dreams"
    }], 1.5, 50.5, 4, "It can lull people to sleep and make them dream. It is active during nights of the new moon.", {
      mythical: true
    }), P(658, "Greninja", "Ninja Pokémon", ["water", "dark"], [72, 95, 67, 103, 71, 122], [{
      name: "Torrent"
    }, {
      name: "Protean",
      hidden: true
    }], 1.5, 40.0, 6, "It creates throwing stars out of compressed water. It moves through the night with unrivaled stealth."), P(700, "Sylveon", "Intertwining Pokémon", ["fairy"], [95, 65, 65, 110, 130, 60], [{
      name: "Cute Charm"
    }, {
      name: "Pixilate",
      hidden: true
    }], 1.0, 23.5, 6, "It sends a soothing aura from its ribbonlike feelers to calm fights and quell hostility."), P(778, "Mimikyu", "Disguise Pokémon", ["ghost", "fairy"], [55, 90, 80, 50, 105, 96], [{
      name: "Disguise"
    }], 0.2, 0.7, 7, "Its actual appearance is unknown. A scholar who saw what was inside its cloth was overcome with fear."), P(887, "Dragapult", "Stealth Pokémon", ["dragon", "ghost"], [88, 120, 75, 100, 75, 142], [{
      name: "Clear Body"
    }, {
      name: "Infiltrator"
    }, {
      name: "Cursed Body",
      hidden: true
    }], 3.0, 50.0, 8, "It can fold its body to fit into very small spaces, and likes to hide in narrow gaps."), P(909, "Sprigatito", "Grass Cat Pokémon", ["grass"], [40, 61, 54, 45, 45, 65], [{
      name: "Overgrow"
    }, {
      name: "Protean",
      hidden: true
    }], 0.4, 4.1, 9, "Its fluffy fur is similar in composition to plants. This Pokémon frequently washes its face to keep it from drying out.")]
  };
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/explorer/data.js", error: String((e && e.message) || e) }); }

// ui_kits/explorer/icons.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/* Lucide icon set (https://lucide.dev) — copied path data, rendered inline so
   they survive React re-renders. 1.75 stroke, currentColor. */
(function () {
  const I = paths => function Icon({
    size = 20,
    className = "",
    ...rest
  }) {
    return /*#__PURE__*/React.createElement("svg", _extends({
      xmlns: "http://www.w3.org/2000/svg",
      width: size,
      height: size,
      viewBox: "0 0 24 24",
      fill: "none",
      stroke: "currentColor",
      strokeWidth: "1.75",
      strokeLinecap: "round",
      strokeLinejoin: "round",
      className: className,
      "aria-hidden": "true"
    }, rest), paths);
  };
  window.PokeIcons = {
    Sliders: I(/*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("line", {
      x1: "4",
      x2: "4",
      y1: "21",
      y2: "14"
    }), /*#__PURE__*/React.createElement("line", {
      x1: "4",
      x2: "4",
      y1: "10",
      y2: "3"
    }), /*#__PURE__*/React.createElement("line", {
      x1: "12",
      x2: "12",
      y1: "21",
      y2: "12"
    }), /*#__PURE__*/React.createElement("line", {
      x1: "12",
      x2: "12",
      y1: "8",
      y2: "3"
    }), /*#__PURE__*/React.createElement("line", {
      x1: "20",
      x2: "20",
      y1: "21",
      y2: "16"
    }), /*#__PURE__*/React.createElement("line", {
      x1: "20",
      x2: "20",
      y1: "12",
      y2: "3"
    }), /*#__PURE__*/React.createElement("line", {
      x1: "2",
      x2: "6",
      y1: "14",
      y2: "14"
    }), /*#__PURE__*/React.createElement("line", {
      x1: "10",
      x2: "14",
      y1: "8",
      y2: "8"
    }), /*#__PURE__*/React.createElement("line", {
      x1: "18",
      x2: "22",
      y1: "16",
      y2: "16"
    }))),
    ArrowLeft: I(/*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("path", {
      d: "m12 19-7-7 7-7"
    }), /*#__PURE__*/React.createElement("path", {
      d: "M19 12H5"
    }))),
    Ruler: I(/*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("path", {
      d: "M21.3 15.3a2.4 2.4 0 0 1 0 3.4l-2.6 2.6a2.4 2.4 0 0 1-3.4 0L2.7 8.7a2.41 2.41 0 0 1 0-3.4l2.6-2.6a2.41 2.41 0 0 1 3.4 0Z"
    }), /*#__PURE__*/React.createElement("path", {
      d: "m14.5 12.5 2-2"
    }), /*#__PURE__*/React.createElement("path", {
      d: "m11.5 9.5 2-2"
    }), /*#__PURE__*/React.createElement("path", {
      d: "m8.5 6.5 2-2"
    }), /*#__PURE__*/React.createElement("path", {
      d: "m17.5 15.5 2-2"
    }))),
    Weight: I(/*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("circle", {
      cx: "12",
      cy: "5",
      r: "3"
    }), /*#__PURE__*/React.createElement("path", {
      d: "M6.5 8a2 2 0 0 0-1.905 1.46L2.1 18.5A2 2 0 0 0 4 21h16a2 2 0 0 0 1.925-2.54L19.4 9.46A2 2 0 0 0 17.48 8Z"
    }))),
    Sparkles: I(/*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("path", {
      d: "M9.937 15.5A2 2 0 0 0 8.5 14.063l-6.135-1.582a.5.5 0 0 1 0-.962L8.5 9.936A2 2 0 0 0 9.937 8.5l1.582-6.135a.5.5 0 0 1 .963 0L14.063 8.5A2 2 0 0 0 15.5 9.937l6.135 1.581a.5.5 0 0 1 0 .964L15.5 14.063a2 2 0 0 0-1.437 1.437l-1.582 6.135a.5.5 0 0 1-.963 0z"
    }), /*#__PURE__*/React.createElement("path", {
      d: "M20 3v4"
    }), /*#__PURE__*/React.createElement("path", {
      d: "M22 5h-4"
    }), /*#__PURE__*/React.createElement("path", {
      d: "M4 17v2"
    }), /*#__PURE__*/React.createElement("path", {
      d: "M5 18H3"
    }))),
    Layers: I(/*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("path", {
      d: "M12.83 2.18a2 2 0 0 0-1.66 0L2.6 6.08a1 1 0 0 0 0 1.83l8.58 3.91a2 2 0 0 0 1.66 0l8.58-3.9a1 1 0 0 0 0-1.83Z"
    }), /*#__PURE__*/React.createElement("path", {
      d: "M2 12a1 1 0 0 0 .58.91l8.6 3.91a2 2 0 0 0 1.65 0l8.58-3.9A1 1 0 0 0 22 12"
    }), /*#__PURE__*/React.createElement("path", {
      d: "M2 17a1 1 0 0 0 .58.91l8.6 3.91a2 2 0 0 0 1.65 0l8.58-3.9A1 1 0 0 0 22 17"
    }))),
    Tag: I(/*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("path", {
      d: "M12.586 2.586A2 2 0 0 0 11.172 2H4a2 2 0 0 0-2 2v7.172a2 2 0 0 0 .586 1.414l8.704 8.704a2.426 2.426 0 0 0 3.42 0l6.58-6.58a2.426 2.426 0 0 0 0-3.42z"
    }), /*#__PURE__*/React.createElement("circle", {
      cx: "7.5",
      cy: "7.5",
      r: ".5",
      fill: "currentColor"
    }))),
    ExternalLink: I(/*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("path", {
      d: "M15 3h6v6"
    }), /*#__PURE__*/React.createElement("path", {
      d: "M10 14 21 3"
    }), /*#__PURE__*/React.createElement("path", {
      d: "M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"
    }))),
    Hash: I(/*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("line", {
      x1: "4",
      x2: "20",
      y1: "9",
      y2: "9"
    }), /*#__PURE__*/React.createElement("line", {
      x1: "4",
      x2: "20",
      y1: "15",
      y2: "15"
    }), /*#__PURE__*/React.createElement("line", {
      x1: "10",
      x2: "8",
      y1: "3",
      y2: "21"
    }), /*#__PURE__*/React.createElement("line", {
      x1: "16",
      x2: "14",
      y1: "3",
      y2: "21"
    })))
  };
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/explorer/icons.jsx", error: String((e && e.message) || e) }); }

__ds_ns.Button = __ds_scope.Button;

__ds_ns.Checkbox = __ds_scope.Checkbox;

__ds_ns.IconButton = __ds_scope.IconButton;

__ds_ns.Input = __ds_scope.Input;

__ds_ns.SearchInput = __ds_scope.SearchInput;

__ds_ns.Select = __ds_scope.Select;

__ds_ns.Switch = __ds_scope.Switch;

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.Card = __ds_scope.Card;

__ds_ns.PokemonCard = __ds_scope.PokemonCard;

__ds_ns.StatBar = __ds_scope.StatBar;

__ds_ns.POKEMON_TYPES = __ds_scope.POKEMON_TYPES;

__ds_ns.TypeBadge = __ds_scope.TypeBadge;

__ds_ns.EmptyState = __ds_scope.EmptyState;

__ds_ns.Pagination = __ds_scope.Pagination;

})();

/* Pokédex Explorer — sample dataset for the UI kit.
   A curated slice of the National Dex with full detail, spanning types,
   generations, and legendary/mythical status. Artwork resolves to the
   public PokéAPI sprites CDN via id (see artworkUrl in PokemonCard). */
(function () {
  const P = (id, name, genus, types, stats, abilities, height, weight, generation, flavor, flags = {}) => ({
    id, name, genus, types,
    stats: { hp: stats[0], atk: stats[1], def: stats[2], spa: stats[3], spd: stats[4], spe: stats[5] },
    abilities, height, weight, generation,
    legendary: !!flags.legendary, mythical: !!flags.mythical,
    flavor,
  });

  window.PokedexData = {
    pageSize: 12, // NOTE: production spec is 20/page (FR-LIST-01); 12 reads better in the kit grid.
    generations: [
      { value: "1", label: "Gen 1 — Kanto" },
      { value: "2", label: "Gen 2 — Johto" },
      { value: "3", label: "Gen 3 — Hoenn" },
      { value: "4", label: "Gen 4 — Sinnoh" },
      { value: "5", label: "Gen 5 — Unova" },
      { value: "6", label: "Gen 6 — Kalos" },
      { value: "7", label: "Gen 7 — Alola" },
      { value: "8", label: "Gen 8 — Galar" },
      { value: "9", label: "Gen 9 — Paldea" },
    ],
    pokemon: [
      P(1,  "Bulbasaur",  "Seed Pokémon",     ["grass","poison"], [45,49,49,65,65,45], [{name:"Overgrow"},{name:"Chlorophyll",hidden:true}], 0.7, 6.9, 1, "A strange seed was planted on its back at birth. The plant sprouts and grows with this Pokémon."),
      P(4,  "Charmander", "Lizard Pokémon",   ["fire"],           [39,52,43,60,50,65], [{name:"Blaze"},{name:"Solar Power",hidden:true}], 0.6, 8.5, 1, "Obviously prefers hot places. When it rains, steam is said to spout from the tip of its tail."),
      P(6,  "Charizard",  "Flame Pokémon",    ["fire","flying"],  [78,84,78,109,85,100], [{name:"Blaze"},{name:"Solar Power",hidden:true}], 1.7, 90.5, 1, "Spits fire that is hot enough to melt boulders. May cause forest fires by blowing flames."),
      P(7,  "Squirtle",   "Tiny Turtle Pokémon", ["water"],       [44,48,65,50,64,43], [{name:"Torrent"},{name:"Rain Dish",hidden:true}], 0.5, 9.0, 1, "After birth, its back swells and hardens into a shell. Powerfully sprays foam from its mouth."),
      P(25, "Pikachu",    "Mouse Pokémon",    ["electric"],       [35,55,40,50,50,90], [{name:"Static"},{name:"Lightning Rod",hidden:true}], 0.4, 6.0, 1, "When several of these Pokémon gather, their electricity could build and cause lightning storms."),
      P(94, "Gengar",     "Shadow Pokémon",   ["ghost","poison"], [60,65,60,130,75,110], [{name:"Cursed Body"}], 1.5, 40.5, 1, "Under a full moon, this Pokémon likes to mimic the shadows of people and laugh at their fright."),
      P(130,"Gyarados",   "Atrocious Pokémon",["water","flying"], [95,125,79,60,100,81], [{name:"Intimidate"},{name:"Moxie",hidden:true}], 6.5, 235.0, 1, "Rarely seen in the wild. Huge and vicious, it is capable of destroying entire cities in a rage."),
      P(143,"Snorlax",    "Sleeping Pokémon", ["normal"],         [160,110,65,65,110,30], [{name:"Immunity"},{name:"Gluttony",hidden:true}], 2.1, 460.0, 1, "Very lazy. Just eats and sleeps. As its rotund bulk builds, it becomes steadily more slothful."),
      P(149,"Dragonite",  "Dragon Pokémon",   ["dragon","flying"],[91,134,95,100,100,80], [{name:"Inner Focus"},{name:"Multiscale",hidden:true}], 2.2, 210.0, 1, "An extremely rarely seen marine Pokémon. Its intelligence is said to match that of humans."),
      P(150,"Mewtwo",     "Genetic Pokémon",  ["psychic"],        [106,110,90,154,90,130], [{name:"Pressure"},{name:"Unnerve",hidden:true}], 2.0, 122.0, 1, "Created by a scientist after years of horrific gene-splicing and DNA-engineering experiments.", {legendary:true}),
      P(151,"Mew",        "New Species Pokémon",["psychic"],      [100,100,100,100,100,100], [{name:"Synchronize"}], 0.4, 4.0, 1, "So rare it is still said to be a mirage by many experts. Only a few people have seen it worldwide.", {mythical:true}),
      P(196,"Espeon",     "Sun Pokémon",      ["psychic"],        [65,65,60,130,95,110], [{name:"Synchronize"},{name:"Magic Bounce",hidden:true}], 0.9, 26.5, 2, "It uses the fine hair covering its body to sense air currents and predict its enemy's actions."),
      P(248,"Tyranitar",  "Armor Pokémon",    ["rock","dark"],    [100,134,110,95,100,61], [{name:"Sand Stream"},{name:"Unnerve",hidden:true}], 2.0, 202.0, 2, "Its body can't be harmed by any sort of attack, so it is very eager to make challenges."),
      P(257,"Blaziken",   "Blaze Pokémon",    ["fire","fighting"],[80,120,70,110,70,80], [{name:"Blaze"},{name:"Speed Boost",hidden:true}], 1.9, 52.0, 3, "Learns powerful kicks. Can leap over a building in one bound. Its blazing punches leave scorch marks."),
      P(282,"Gardevoir",  "Embrace Pokémon",  ["psychic","fairy"],[68,65,65,125,115,80], [{name:"Synchronize"},{name:"Trace"},{name:"Telepathy",hidden:true}], 1.6, 48.4, 3, "To protect its Trainer, it will expend all its psychic power to create a small black hole."),
      P(384,"Rayquaza",   "Sky High Pokémon", ["dragon","flying"],[105,150,90,150,90,95], [{name:"Air Lock"}], 7.0, 206.5, 3, "It flies forever through the ozone layer, consuming meteoroids for sustenance.", {legendary:true}),
      P(448,"Lucario",    "Aura Pokémon",     ["fighting","steel"],[70,110,70,115,70,90], [{name:"Steadfast"},{name:"Inner Focus"},{name:"Justified",hidden:true}], 1.2, 54.0, 4, "By catching the aura emanating from others, it can read their thoughts and movements."),
      P(445,"Garchomp",   "Mach Pokémon",     ["dragon","ground"],[108,130,95,80,85,102], [{name:"Sand Veil"},{name:"Rough Skin",hidden:true}], 1.9, 95.0, 4, "When it folds up its body and extends its wings, it looks like a jet plane and flies at sonic speed."),
      P(491,"Darkrai",    "Pitch-Black Pokémon",["dark"],         [70,90,90,135,90,125], [{name:"Bad Dreams"}], 1.5, 50.5, 4, "It can lull people to sleep and make them dream. It is active during nights of the new moon.", {mythical:true}),
      P(658,"Greninja",   "Ninja Pokémon",    ["water","dark"],   [72,95,67,103,71,122], [{name:"Torrent"},{name:"Protean",hidden:true}], 1.5, 40.0, 6, "It creates throwing stars out of compressed water. It moves through the night with unrivaled stealth."),
      P(700,"Sylveon",    "Intertwining Pokémon",["fairy"],       [95,65,65,110,130,60], [{name:"Cute Charm"},{name:"Pixilate",hidden:true}], 1.0, 23.5, 6, "It sends a soothing aura from its ribbonlike feelers to calm fights and quell hostility."),
      P(778,"Mimikyu",    "Disguise Pokémon", ["ghost","fairy"],  [55,90,80,50,105,96], [{name:"Disguise"}], 0.2, 0.7, 7, "Its actual appearance is unknown. A scholar who saw what was inside its cloth was overcome with fear."),
      P(887,"Dragapult",  "Stealth Pokémon",  ["dragon","ghost"], [88,120,75,100,75,142], [{name:"Clear Body"},{name:"Infiltrator"},{name:"Cursed Body",hidden:true}], 3.0, 50.0, 8, "It can fold its body to fit into very small spaces, and likes to hide in narrow gaps."),
      P(909,"Sprigatito",  "Grass Cat Pokémon",["grass"],         [40,61,54,45,45,65], [{name:"Overgrow"},{name:"Protean",hidden:true}], 0.4, 4.1, 9, "Its fluffy fur is similar in composition to plants. This Pokémon frequently washes its face to keep it from drying out."),
    ],
  };
})();
